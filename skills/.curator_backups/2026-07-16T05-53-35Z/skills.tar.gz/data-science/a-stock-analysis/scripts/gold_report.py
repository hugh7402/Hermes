#!/usr/bin/env python3
"""每日黄金分析报告 - 国内金价长线跟踪 - akshare 数据源"""
import akshare as ak
from datetime import datetime

def get_gold_report():
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    
    lines = [f"📊 每日黄金分析报告", f"📅 {today}\n"]

    try:
        df = ak.spot_golden_benchmark_sge()
        if df is not None and len(df) > 0:
            latest = df.iloc[-1]
            lines.append("💰 上海金交所 Au99.99")
            price = latest.get('早盘价') or latest.get('晚盘价') or '--'
            lines.append(f"   最新价: {price} 元/克")
            if len(df) >= 2:
                prev = df.iloc[-2]
                prev_price = prev.get('早盘价') or prev.get('晚盘价') or 0
                if price != '--' and prev_price:
                    change = float(price) - float(prev_price)
                    pct = change / float(prev_price) * 100
                    arrow = "🔺" if change > 0 else "🔻" if change < 0 else "➖"
                    lines.append(f"   日涨跌: {arrow} {change:+.2f} ({pct:+.2f}%)")
        lines.append("")
    except:
        lines.append(f"💰 Au99.99: 获取失败\n")

    lines.append("🌍 宏观背景")
    try:
        cn_gold = ak.macro_china_fx_gold()
        if cn_gold is not None and len(cn_gold) > 0:
            latest_gold = cn_gold.iloc[-1]
            val = latest_gold.get('黄金储备-数值', '--')
            month = latest_gold.get('月份', '')
            lines.append(f"   中国黄金储备({month}): {val} 万盎司")
    except:
        lines.append(f"   黄金储备: 获取失败")

    try:
        us_rate = ak.macro_australia_bank_rate()
        if us_rate is not None and len(us_rate) > 0:
            latest_us = us_rate.iloc[-1]
            val = latest_us.get('现值', '--')
            t = latest_us.get('时间', '')
            lines.append(f"   澳洲基准利率({t}): {val}%（参考）")
    except:
        lines.append(f"   澳洲利率: 获取失败")

    lines.append("")
    lines.append("—" * 30)
    lines.append("⚠️ 仅供参考，不构成投资建议")
    return "\n".join(lines)

if __name__ == "__main__":
    print(get_gold_report())