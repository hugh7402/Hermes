---
name: project-daily-report
description: 从项目双周任务 Excel 清单生成日报 Word 文档 — 读取 xlsx，按截止日期或全部任务统计，按负责人分组，输出 Word 文档和微信文本。适用于政府信息化项目进度汇报。
version: 1.0.0
author: Emma
---

# 项目日报生成智能体

从双周任务清单 Excel (.xlsx) 生成格式化的日报 Word 文档，同时支持输出微信文本格式。

## 触发条件

用户说以下内容时加载此技能：
- "生成日报" / "出一版日报"
- "按这个最新清单出具日报"
- "根据这份文件出日报"
- 用户发来项目任务清单 Excel 文件并要求分析

## 数据来源

- 文件：双周任务清单 xlsx，包含 3 个 Sheet
- Sheet1「**双周任务清单**」= 主数据：
  - D列（系统名称）、I列（板块负责人）、J列（完成日期 序列号）、K列（完成状态）
  - B列（分类）、C列（工作项）、F列（任务内容）、E列（业务处室）
- Sheet2「**任务完成统计透视**」= 负责人→系统映射（A列系统名，B列负责人）
- Sheet3「**需求&问题清单**」= 二期需求/问题明细

## 文件读取方式

⚠️ 该 Excel 文件样式复杂，openpyxl 可能报 `Fill() takes no arguments` 错误。**优先使用 ZIP + XML 解析**：

```python
import zipfile, xml.etree.ElementTree as ET
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(filepath) as z:
    ss_root = ET.fromstring(z.read('xl/sharedStrings.xml'))
    # 读取共享字符串
    shared_strings = []
    for si in ss_root.findall('.//s:si', ns):
        texts = [t.text or '' for t in si.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')]
        shared_strings.append(''.join(texts))
    
    def cell_val(c):
        v = c.find('s:v', ns); t = c.get('t', '')
        if v is not None and v.text:
            if t == 's': return shared_strings[int(v.text)] if int(v.text) < len(shared_strings) else v.text
            return v.text
        return ''
    
    # 读取 Sheet1
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    for r in root.findall('.//s:row', ns):
        cells = r.findall('s:c', ns)
        col_map = {}
        for c in cells:
            col_letter = ''.join(filter(str.isalpha, c.get('r', '')))
            col_map[col_letter] = cell_val(c)
        # col_map['D'] = 系统名, col_map['K'] = 状态, col_map['I'] = 负责人
```

## 日报标准结构（用户确认格式）

> ⚠️ 以下格式为最新修订版（2026-07-04），已删除：核心数据行、负责系统文字介绍、空问题条目、"（按负责人）"副标题。

### 一、总体情况
截至今日，双周任务清单中应于 **YYYY年MM月DD日** 前完成的任务共 **N 项**，分布如下：

| 状态 | 数量 | 占比 |
|:----|:---:|:----:|
| ✅ 已完成 | XX | XX% |
| 🔄 进行中 | XX | XX% |
| ❌ 未开始 | XX | **XX%** |
| 🔴 已延期 | XX | XX% |
| ⚠️ 延期风险 | X | X% |

> ❌ 不加「▶ 核心数据」行，用户的明确修正。

### 二、分项情况
> ❌ 标题不加「（按负责人）」后缀。

每位负责人独立表格，格式如下：

**表头**（8列）：系统 | 总数 | 已完成 | 已延期 | 未开始 | 进行中 | 延期风险 | 完成率

- **数据行**：每个系统一行，显示数字和完成率
- **小计行**：底部加总行，**蓝色底纹（#DCE6F1）**，字体加粗
- ❌ **不加「负责 X系统」文字介绍**，用户的明确修正
- 存在问题段落：红色"存在问题："标题 + 延期/风险问题列表，**问题描述为空时不要展示**

### 三、关键发现（已弃用，不再输出）
> 延期问题已移到各负责人表格下方展示，不再单独列章节。

## 数据分组规则

- 从 Sheet1 逐行提取：系统名(D列)、状态(K列)、负责人(I列)
- 用 Sheet2 的负责人映射覆盖 I 列（Sheet2 更准确）
- 按负责人分组，同一负责人下的系统按任务总数降序排列
- 每个负责人按「系统→总数→已完成→已延期→未开始→进行中→完成率」统计

## 输出格式

### 微信文本格式
使用 Markdown 表格，负责人用 `### 🔵 姓名` 作为标题，每个系统一行带 Emoji 标记。

### Word 文档格式 (.docx)
- 用 `python-docx` 生成
- 表格样式：`Light Grid Accent 1`
- 小计行：蓝色底纹（`w:shd fill=DCE6F1`）
- 数据列居中对齐，系统名列左对齐
- 参会人员写在标题下方

## 已知陷阱

1. **openpyxl 兼容性**：该 Excel 的 styles.xml 包含旧版 Fill 格式，openpyxl >= 3.1 可能报错。必须用 ZIP+XML 手动解析，或用 `read_only=True`（仍可能失败）。
2. **序列号日期**：J列完成日期是 Excel 序列号（如 46183 = 2026-05-24），需用 `datetime(1899, 12, 30) + timedelta(days=serial)` 转换。
3. **系统名折行**：Sheet2 中系统名可能含 `\n` 换行符，需先 `replace('\n', ' ').strip()` 再匹配 Sheet1 的系统名。
4. **负责人多值**：部分系统有多个负责人（如"曾祥发、高凯悦"），Sheet2 的 B 列用顿号分隔，显示时保留原格式。
5. **python-docx 设置中文字体**：必须设置 `style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')`，否则中文可能显示异常。
6. **用户要求可编辑**：用户需要 Word 文档以便手动微调数字。生成的文档应确保每个单元格数据独立，不含公式链接。
