#!/opt/data/.venv/bin/python3
"""Generate 陕西智慧民政项目日报 from Excel via XML (openpyxl-compat fallback).
Usage: /opt/data/.venv/bin/python3 gen_daily_report.py <xlsx_path> [YYYY-MM-DD]

Reads Sheet1 (双周任务清单) + Sheet2 (任务完成统计透视).
Filters tasks with due_date <= CUTOFF. Groups by person. Outputs WeChat format.
"""
import zipfile, xml.etree.ElementTree as ET, sys
from datetime import datetime, timedelta
from collections import OrderedDict

FILE = sys.argv[1] if len(sys.argv) > 1 else "/opt/data/cache/documents/doc_71805ca06613_陕西智慧民政项目双周任务和问题清单-20260716.xlsx"
TODAY = datetime.strptime(sys.argv[2], "%Y-%m-%d") if len(sys.argv) > 2 else datetime(2026, 7, 16)
CUTOFF = TODAY

ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def cell_val(c, ss_list):
    v = c.find('s:v', ns)
    t = c.get('t', '')
    if v is not None and v.text:
        if t == 's':
            idx = int(v.text)
            return ss_list[idx] if idx < len(ss_list) else v.text
        return v.text
    return ''

def build_col_map(cells, ss_list):
    col_map = {}
    for c in cells:
        ref = c.get('r', '')
        col_letter = ''.join(filter(str.isalpha, ref))
        col_map[col_letter] = cell_val(c, ss_list)
    return col_map

def excel_to_date(val):
    if not val: return None
    try:
        days = float(val)
        if days >= 1: return datetime(1899, 12, 30) + timedelta(days=days)
    except: pass
    if isinstance(val, str) and val.strip():
        try: return datetime.strptime(val.strip(), "%Y-%m-%d")
        except: pass
    return None

with zipfile.ZipFile(FILE) as z:
    ss_root = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared_strings = []
    for si in ss_root.findall('.//s:si', ns):
        texts = [t.text for t in si.iter(f'{{{ns["s"]}}}t') if t.text]
        shared_strings.append(''.join(texts))

    # Sheet2: person map
    root2 = ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
    person_map = {}
    for row in root2.findall('.//s:row', ns):
        cm = build_col_map(row.findall('s:c', ns), shared_strings)
        sys_name = cm.get('A', '').replace('\n', ' ').strip()
        person = cm.get('B', '').strip()
        if sys_name and person: person_map[sys_name] = person

    # Sheet1: task list
    root1 = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    rows = []
    for row in root1.findall('.//s:row', ns):
        cm = build_col_map(row.findall('s:c', ns), shared_strings)
        sys_name = cm.get('D', '').replace('\n', ' ').strip()
        if not sys_name: continue
        due = excel_to_date(cm.get('J', ''))
        if not due or due > CUTOFF: continue

        person_raw = cm.get('I', '').strip()
        status = cm.get('K', '').strip()
        prob_m = cm.get('M', '').strip()
        prob_n = cm.get('N', '').strip()
        problem = prob_n if prob_n and len(prob_n) > 3 else prob_m

        person = person_map.get(sys_name, person_raw)
        if '、' in person:
            if '曾祥发' in person and '高凯悦' in person:
                person = '曾祥发' if '公共支撑' in sys_name else '高凯悦'
            else:
                person = person.split('、')[0]
        rows.append({'system': sys_name, 'person': person, 'status': status, 'problem': problem})

# ── Stats ──
total = len(rows)
completed = sum(1 for r in rows if r['status'] == '已完成')
in_progress = sum(1 for r in rows if r['status'] == '进行中')
not_started = sum(1 for r in rows if r['status'] == '未开始')
delayed = sum(1 for r in rows if r['status'] == '已延期')
risk = sum(1 for r in rows if r['status'] == '延期风险')

def pct(n): return f'{n/total*100:.0f}%' if total else '0%'
date_str = TODAY.strftime('%Y年%m月%d日')

# ── OUTPUT ──
print(f'📅 **陕西智慧民政项目日报**\n')
print(f'日期：{date_str}  参会人员：邵雷、侯涛、帅航、王紫薇、李思萌、闫帅、王雨阳\n---\n')
print(f'## 一、总体情况\n截至今日共 **{total} 项**\n✅ 已完成 {completed:3d} {pct(completed)} | 🔄 进行中 {in_progress:3d} {pct(in_progress)} | ❌ 未开始 {not_started:3d} {pct(not_started)} | 🔴 已延期 {delayed:3d} {pct(delayed)} | ⚠️ 延期风险 {risk:3d} {pct(risk)}\n---\n## 二、分项情况\n')

person_order = ['侯帅帅','闫帅','帅航','陈彬','李思萌','王紫薇','王雨阳','杜纯','曾祥发','高凯悦','侯涛']
groups = OrderedDict()
for r in rows:
    groups.setdefault(r['person'], []).append(r)

total_done = total_all = 0
for p in person_order:
    if p not in groups: continue
    tasks = groups[p]
    sys_groups = OrderedDict()
    for t in tasks: sys_groups.setdefault(t['system'], []).append(t)
    total_p = len(tasks)
    done_p = sum(1 for t in tasks if t['status'] == '已完成')
    delay_p = sum(1 for t in tasks if t['status'] == '已延期')
    ns_p = sum(1 for t in tasks if t['status'] == '未开始')
    ip_p = sum(1 for t in tasks if t['status'] == '进行中')
    risk_p = sum(1 for t in tasks if t['status'] == '延期风险')
    total_done += done_p; total_all += total_p

    print(f'### 🔵 {p}（{len(sys_groups)}个系统，共 {total_p} 项任务）\n| 系统 | 总数 | 已完成 | 已延期 | 未开始 | 进行中 | 延期风险 | 完成率 |\n|:----|:---:|:-----:|:-----:|:-----:|:-----:|:-------:|:----:|')
    for s, ts in sys_groups.items():
        cnt, d = len(ts), sum(1 for t in ts if t['status'] == '已完成')
        dl = sum(1 for t in ts if t['status'] == '已延期')
        ns = sum(1 for t in ts if t['status'] == '未开始')
        ip = sum(1 for t in ts if t['status'] == '进行中')
        rk = sum(1 for t in ts if t['status'] == '延期风险')
        rate = f'{d/cnt*100:.0f}%'
        print(f'| {s} | {cnt} | {d} | {dl} | {ns} | {ip} | {rk} | {rate} |')
    p_rate = f'{done_p/total_p*100:.0f}%' if total_p else '0%'
    print(f'| **小计** | **{total_p}** | **{done_p}** | **{delay_p}** | **{ns_p}** | **{ip_p}** | **{risk_p}** | **{p_rate}** |')

    issues = []
    for t in tasks:
        if t['status'] in ('已延期','延期风险') and t['problem'] and len(t['problem']) > 3:
            issues.append((t['system'], t['problem']))
    if issues:
        print('\n<font color="red">存在问题：</font>')
        seen = set()
        for s, prob in issues:
            key = f'{s}:{prob[:50]}'
            if key not in seen: seen.add(key); print(f'  🔴 **{s}**：{prob}')
    print()

print('---\n## 三、关键发现\n')
print(f'1. **延期集中**：{delayed}项，养老综合服务（{sum(1 for r in rows if r["system"].startswith("养老") and r["status"]=="已延期")}项）、民政电子档案（{sum(1 for r in rows if r["system"]=="民政电子档案系统" and r["status"]=="已延期")}项）\n2. **分化明显**：帅航({total_done}/{total_all}={total_done/total_all*100:.0f}%) vs 杜纯/王雨阳需加力\n3. **UI进度**：效果图补充中，影响殡葬/福彩/儿童工作台开发')