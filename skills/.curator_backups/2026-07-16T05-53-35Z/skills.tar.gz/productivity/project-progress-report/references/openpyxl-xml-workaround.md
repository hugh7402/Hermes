# openpyxl 样式兼容问题处理

## 问题现象

用 `openpyxl.load_workbook(xlsx, data_only=True)` 读取某些 Excel 文件时报错：

```
TypeError: Fill() takes no arguments
```

## 根因

文件 `xl/styles.xml` 中包含 openpyxl 无法解析的复杂填充样式定义（常见于政府/企业项目文档）。通常在 `load_workbook` 的 `apply_stylesheet()` 阶段崩溃，即使设置 `read_only=True` 也无效。

## 解决方案

放弃 openpyxl 对此类文件的读取，改用 **zipfile + XML 直读**：

```python
import zipfile, xml.etree.ElementTree as ET

with zipfile.ZipFile('file.xlsx') as z:
    ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    
    # 1. 读取共享字符串表
    ss_root = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared_strings = []
    for si in ss_root.findall('.//s:si', ns):
        texts = []
        for t in si.iter(f'{{{ns["s"]}}}t'):
            if t.text: texts.append(t.text)
        shared_strings.append(''.join(texts))
    
    # 2. 单元格取值函数
    def cell_val(c):
        v = c.find('s:v', ns)
        t = c.get('t', '')
        if v is not None and v.text:
            if t == 's':
                idx = int(v.text)
                return shared_strings[idx] if idx < len(shared_strings) else v.text
            return v.text
        return ''
    
    # 3. 按字母获取列值 (如 col_map['D'] = 系统名称)
    def build_col_map(cells):
        col_map = {}
        for c in cells:
            ref = c.get('r', '')  # e.g. 'D2'
            col_letter = ''.join(filter(str.isalpha, ref))
            col_map[col_letter] = cell_val(c)
        return col_map
    
    # 4. 读取 Sheet
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    for row in root.findall('.//s:row', ns):
        cells = row.findall('s:c', ns)
        col_map = build_col_map(cells)
        # col_map['A']... 正常读取
```

## Excel 序列号转日期

```python
from datetime import datetime, timedelta

def excel_to_date(serial_str):
    if not serial_str or not serial_str.strip():
        return None
    try:
        days = float(serial_str)
        if days < 1: return None
        return datetime(1899, 12, 30) + timedelta(days=days)
    except:
        return None
```

## 其他方案（备选）

1. **升级 openpyxl 并修复 styles.xml**：用 zipfile 解压后手动删除 `xl/styles.xml` 中问题节点再重打包 — 不推荐，复杂且不通用
2. **libreoffice 命令行转换**：`libreoffice --headless --convert-to csv file.xlsx` — 会丢失多 sheet + 中文乱码
3. **pandas + calamine 引擎**：`pd.read_excel(engine='calamine')` — 需额外安装，不如 XML 直读灵活
4. **markitdown**：微软官方工具，但只能转文本，无法按列取值
