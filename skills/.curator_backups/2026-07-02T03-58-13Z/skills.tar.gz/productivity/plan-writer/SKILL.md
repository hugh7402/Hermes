---
name: plan-writer
description: "专门用于撰写政务信息化方案、报告、建议书。使用硅基流动 deepseek-ai/DeepSeek-V4-Pro（当前 2.5 折优惠，47s，技术准确度 8.0/10），采用两轮制（架构设计 → 全文一次生成），检索 Obsidian 知识库获取真实参考内容，输出到 OutPut Box 并微信推送。"
version: 2.0.0
author: Emma
created_by: agent
metadata:
  agent:
    tags: [方案, 报告, 建议书, 政务, 信息化, 架构设计, 方案智能体]
    usage_count: 0
---

# 方案智能体 (Plan Writer)

专门用于撰写政务信息化方案、报告、建议书。采用两轮制流程，利用硅基流动的 DeepSeek-V4-Pro 模型。

## 触发条件

用户说以下内容时加载此技能：
- "写方案" / "写个方案"
- "帮我写..."（指代方案/报告/建议书）
- "起草一份..."

## 模型配置

- **主模型**: deepseek-ai/DeepSeek-V4-Pro (硅基流动平台)
- **优势**: 技术准确度高(8.0/10)、内容质量满分(10/10)、当前2.5折优惠
- **API**: https://api.siliconflow.cn/v1/chat/completions
- **Key**: SILICONFLOW_API_KEY（.env 中）
- **⚠️ 注意**: DeepSeek-V4-Pro 需要 max_tokens ≥ 8000 才能输出完整方案
- **备用模型**: qwen3.7-max（百炼平台），硅基流动不可用时切换。注意延迟较高（~58s）、输出偏简洁，适当调高 temperature 改善

## 工作流程

### 第1轮：架构设计（call_llm 第1次）

分析需求 → 检索知识库 → 输出：目录结构 + 每节核心论点 + 对比选型表格

### 第2轮：全文撰写（call_llm 第2次）

基于架构 + 知识库参考内容 → 一次生成完整方案

## 知识库检索

搜索以下目录的 Markdown 笔记作为参考：
- `concepts/` — WebChat 备份文档
- `00-INBOX/` — 思源笔记

按关键词命中率排序，取前 10 篇最相关笔记。

## 输出

- 保存在 `/opt/data/OutPut Box/`（命名：`方案-YYYYMMDD-HHMM/`）
- 生成 index.md 索引文件（标题 + 摘要 + 字数）
- 推送微信通知

## 技术栈

- Python 3（标准库 + 无额外依赖）
- 硅基流动 API（OpenAI 兼容格式）
- Obsidian Vault 知识库参考

## 已知陷阱

1. **max_tokens 不足** — DeepSeek-V4-Pro 写完整方案需要 ≥ 8000 tokens，否则会截断
2. **超时控制** — 方案较长时 API 调用可能超过 120s，设置 timeout=300
3. **备用模型** — qwen3.7-max（百炼平台），硅基流动不可用时自动切换。注意 qwen3.7-max 延迟较高（约58s），输出偏简洁，需适当调整 temperature。
