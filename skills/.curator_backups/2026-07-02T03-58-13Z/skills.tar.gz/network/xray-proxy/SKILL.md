---
name: xray-proxy
description: 在无 systemd 的容器/无头服务器中，从 V2Ray VLESS 订阅链接搭建 xray SOCKS5/HTTP 代理，批量测试节点可用性，持久后台运行。
---

# xray-proxy

在容器/无头环境中从 VLESS 订阅搭建 xray 代理，用于访问被墙网站（javdb, YouTube 等）。

## 触发条件

- 用户说「装个代理」「翻墙」「上不去 javdb」「xray」「V2Ray」
- 用户提供了 VLESS 订阅链接或节点配置
- 容器/服务器没有 systemd，不能跑标准 VPN 客户端

## 工作流

### 1. 获取 xray 二进制

如果 GitHub 被墙，从 Gitee 镜像下载（实测 gitee.com 在国内可访问）：

```bash
# 从 GitHub 官方下载
curl -sL https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip -o /tmp/xray.zip

# 从 Gitee 镜像下载（GitHub 被墙时）
curl -sL https://gitee.com/xtls/Xray-core/releases/download/v26.3.27/Xray-linux-64.zip -o /tmp/xray.zip

cd /tmp && unzip -o xray.zip -d xray/ && rm xray.zip
# 验证: /tmp/xray/xray version
```

> ⚠️ 如果 `unzip` 未安装，用 `apt install unzip -y` 安装。

### 2. 解析订阅链接

订阅内容为 base64 编码的多行 VLESS 链接，每行格式：
```
vless://<uuid>@<host>:<port>?type=<transport>&security=<tls|reality>&...&pbk=<publicKey>&sid=<shortId>#<名称>
```

关键参数：
| 参数 | 用途 | 必填（reality） |
|:----|:----|:----:|
| `type` | 传输协议：`tcp` / `ws` | ✅ |
| `security` | 加密方式：`tls` / `reality` | ✅ |
| `flow` | 流控：`xtls-rprx-vision` | ✅ |
| `sni` | TLS SNI 域名 | ✅ |
| `fp` | TLS 指纹：`chrome` / `ios` / `safari` | ✅ |
| `pbk` | Reality 公钥（**极易遗漏！**） | ✅ reality only |
| `sid` | Reality shortId（**极易遗漏！**） | ✅ reality only |
| `host` | WebSocket Host 头 | ✅ WS TLS only |
| `path` | WebSocket 路径 | ✅ WS TLS only |

**⚠️ 关键陷阱**：解析 VLESS 链接时，`pbk` 和 `sid` 参数在链接末尾（`#` 之前），如 `curl` 输出截断会丢失！务必获取完整链接（400+ chars）。使用 `re.findall(r'vless://[^\s\r\n]+', decoded)` 确保捕获完整链接。

### 3. 构建 xray 配置

#### Reality（三网推荐节点）

```python
config = {
    "log": {"loglevel": "warning"},
    "inbounds": [{
        "tag": "socks-in", "port": 10808, "listen": "127.0.0.1",
        "protocol": "socks", "settings": {"auth": "noauth", "udp": True}
    }, {
        "tag": "http-in", "port": 10809, "listen": "127.0.0.1",
        "protocol": "http", "settings": {}
    }],
    "outbounds": [{
        "tag": "proxy", "protocol": "vless",
        "settings": {
            "vnext": [{
                "address": host, "port": port,
                "users": [{"id": uuid, "encryption": "none", "flow": flow}]
            }]
        },
        "streamSettings": {
            "network": "tcp", "security": "reality",
            "realitySettings": {
                "serverName": sni,           # 从 VLESS 的 sni 参数
                "fingerprint": fp,            # ios/chrome/safari
                "show": False,
                "publicKey": pbk,             # ⚠️ 必须！从 VLESS 的 pbk 参数
                "shortId": sid                # ⚠️ 必须！从 VLESS 的 sid 参数
            }
        }
    }]
}
```

#### WebSocket + TLS（Cloudflare CDN 节点）

```python
config["outbounds"][0]["streamSettings"] = {
    "network": "ws",
    "security": "tls",
    "tlsSettings": {
        "serverName": sni or host_header,
        "fingerprint": fp,
        "allowInsecure": insecure == "1"
    },
    "wsSettings": {
        "path": path,                        # 从 VLESS 的 path 参数
        "headers": {"Host": host_header}     # 从 VLESS 的 host 参数
    }
}
```

### 4. 启动和测试

```bash
# 启动 xray（后台持久运行）
nohup /tmp/xray/xray run -c /opt/data/xray_config.json > xray_stdout.log 2>&1 &

# 测试代理
export https_proxy=socks5://127.0.0.1:10808
curl -s --socks5 127.0.0.1:10808 https://httpbin.org/ip   # 查出口 IP
curl -s -L -o /dev/null -w "%{http_code}" --socks5 127.0.0.1:10808 https://www.javdb.com  # 测试目标站
```

测试结果解释：
- `200` ✅ 完全可用
- `301` / `302` ⚠️ 可用（重定向到首页/登录）
- `403` ❌ IP 被目标站封禁
- `000` / 超时 ❌ 代理未连通或配置错误

### 5. 批量测试节点

从订阅中提取所有节点，逐个启动 xray → 测试目标站 → 记录结果。重点优先测试标有「三网推荐」的节点。

典型测试方法：

```python
# 对每个节点:
# 1. 构建配置写入临时文件
# 2. 启动 xray 子进程，等 2s 启动
# 3. curl --socks5 127.0.0.1:10808 测试目标站
# 4. 终止 xray，清临时文件
# 5. 间隔 1s 再测下一个（避免端口冲突）
```

> ⚠️ 子进程启动后要 `time.sleep(2)` 等 xray 初始化完成再测。

## 持久化运行

在无 systemd 的容器中，用 nohup + PID 文件管理：

```bash
# start_xray.sh
PIDFILE="/opt/data/xray.pid"
nohup /tmp/xray/xray run -c /opt/data/xray_config.json > /opt/data/xray_stdout.log 2>&1 &
echo $! > $PIDFILE

# 停止
kill $(cat /opt/data/xray.pid)

# 检查是否存活
kill -0 $(cat /opt/data/xray.pid) && echo "running"
```

> 容器重启后需要手动重新启动 xray。

## 管理脚本

参考 `/opt/data/start_xray.sh` — 启动/停止/验证一体化脚本。

## 验证

```bash
curl -s --socks5 127.0.0.1:10808 --connect-timeout 5 --max-time 10 https://www.google.com
# 应返回 HTTP 200

curl -s --socks5 127.0.0.1:10808 --connect-timeout 5 --max-time 10 https://httpbin.org/ip
# 应返回出口 IP（非本地 IP）
```

## Pitfalls

- **Reality 配置缺少 pbk/sid 会直接启动失败**：错误信息 `Failed to build REALITY config. > empty "password"`。必须从 VLESS 链接的 `pbk` 和 `sid` 参数提取。
- **curl 输出截断**：VLESS 链接长度 300-500 chars，使用 `re.findall` 正则提取完整链接，不要手工截取。
- **端口冲突**：前一个 xray 进程未完全退出时，新进程绑定 10808 会失败。每次测试先 `pkill -f xray` 并 `sleep 1`。
- **子进程启动等待**：xray 需要约 2s 初始化。测试前必须 `time.sleep(2)`，否则会返回 000。
- **Gateway 内重启限制**：`hermes gateway restart` 在 gateway 进程中执行会拒绝（防止死循环）。需从独立终端执行或让用户手动重启。
- **节点 IP 被封**：目标站（如 javdb）会封禁已知代理 IP 段。同一节点的不同子节点（圣何塞01-08）可能部分被封、部分可用，需全部测试。
- **pkill -f xray 自杀问题**：在 terminal() 中执行 `pkill -f xray` 会连带杀掉自己的进程（因为它也匹配了 xray）。解决：先 `pkill -f "xray" 2>/dev/null; sleep 2` 确保旧进程退出，再在新 terminal() 中启动。
