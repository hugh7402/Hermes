# AudioCraft — MusicGen Text-to-Music

Absorbed from `audiocraft-audio-generation` skill.

## Overview
Meta's AudioCraft framework: MusicGen (text-to-music) and AudioGen (text-to-sound). Generates high-quality audio from text descriptions and audio prompts.

## Installation

```bash
git clone https://github.com/facebookresearch/audiocraft.git
cd audiocraft
python -m venv venv
source venv/bin/activate
pip install -e .
```

## Usage — MusicGen

### Basic text-to-music
```python
from audiocraft.models import MusicGen
from audiocraft.data.audio import audio_write
import torchaudio

model = MusicGen.get_pretrained('melody')
model.set_generation_params(duration=8)  # seconds

wav = model.generate([
    '80s synth pop with energetic female vocals',
    'calm classical piano with strings',
])

for idx, one_wav in enumerate(wav):
    audio_write(f'music_{idx}', one_wav.cpu(), model.sample_rate)
```

### With melody conditioning
```python
melody, sr = torchaudio.load('./melody.wav')
wav = model.generate_with_chroma(
    ['chill lo-fi beat with vinyl crackle'],
    melody[None].expand(1, -1, -1),
    sr,
)
```

## Using from terminal
```bash
python -m audiocraft.musicgen \
  --model facebook/musicgen-melody \
  --prompt "80s synth pop with energetic female vocals" \
  --duration 8 \
  --output ./output/
```

## Parameters
| Parameter | Default | Description |
|---|---|---|
| `duration` | 8 | Generation duration in seconds |
| `top_k` | 250 | Top-k filtering |
| `top_p` | 0.0 | Nucleus sampling |
| `temperature` | 1.0 | Sampling temperature |
| `cfg_coef` | 3.0 | Classifier-free guidance scale |

## Models
| Model | Size | Description |
|---|---|---|
| `facebook/musicgen-small` | 300M | Fast, lower quality |
| `facebook/musicgen-medium` | 1.5B | Good quality (recommended) |
| `facebook/musicgen-melody` | 1.5B | Supports melody conditioning |
| `facebook/musicgen-large` | 3.3B | Best quality, slowest |

## Hardware
- small: 4GB VRAM
- medium/melody: 6-8GB VRAM
- large: 12-16GB VRAM

## Links
- Repo: https://github.com/facebookresearch/audiocraft
- License: MIT (code), CC-BY-NC-4.0 (models)
