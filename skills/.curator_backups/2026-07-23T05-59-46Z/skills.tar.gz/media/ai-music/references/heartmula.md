# HeartMuLa — Open-Source Music Generation

Absorbed from `heartmula` skill.

## Overview

HeartMuLa family of open-source music foundation models (Apache-2.0). Generates full songs from lyrics + tags. Comparable to Suno for open-source.

Includes:
- **HeartMuLa** — Music language model (3B/7B)
- **HeartCodec** — 12.5Hz music codec
- **HeartTranscriptor** — Whisper-based lyrics transcription
- **HeartCLAP** — Audio-text alignment model

## Hardware Requirements
- Minimum: 8GB VRAM with `--lazy_load true`
- Recommended: 16GB+ VRAM
- 3B model with lazy_load peaks at ~6.2GB VRAM

## Installation

```bash
git clone https://github.com/HeartMuLa/heartlib.git
cd heartlib
uv venv --python 3.10 .venv
source .venv/bin/activate
uv pip install -e .
uv pip install --upgrade datasets transformers
```

Patch source code for transformers 5.x compatibility (see original `heartmula` skill for exact patches).

## Download Models
```bash
hf download --local-dir './ckpt' 'HeartMuLa/HeartMuLaGen'
hf download --local-dir './ckpt/HeartMuLa-oss-3B' 'HeartMuLa/HeartMuLa-oss-3B-happy-new-year'
hf download --local-dir './ckpt/HeartCodec-oss' 'HeartMuLa/HeartCodec-oss-20260123'
```

## Usage
```bash
python ./examples/run_music_generation.py \
  --model_path=./ckpt --version="3B" \
  --lyrics="./assets/lyrics.txt" --tags="./assets/tags.txt" \
  --save_path="./assets/output.mp3" --lazy_load true
```

### Key Parameters
| Parameter | Default | Description |
|---|---|---|
| `--max_audio_length_ms` | 240000 | Max length in ms |
| `--topk` | 50 | Top-k sampling |
| `--temperature` | 1.0 | Sampling temperature |
| `--cfg_scale` | 1.5 | Classifier-free guidance |

### Input Formatting
**Tags**: comma-separated, no spaces: `piano,happy,wedding`
**Lyrics**: use bracketed structural tags like [Verse], [Chorus], [Bridge]

### Performance
- RTF ≈ 1.0 — 4-min song takes ~4 minutes
- Output: MP3, 48kHz stereo, 128kbps
- No GPU? CPU mode is extremely slow (30-60+ minutes per song)

## Pitfalls
1. Do NOT use bf16 for HeartCodec — degrades quality. Use fp32.
2. Tags may be ignored (known issue #90)
3. Linux/CUDA only for GPU (no macOS Triton)
4. RTX 5080 incompatibility reported upstream
5. Dependency pin conflicts require manual upgrades and patches

## Links
- Repo: https://github.com/HeartMuLa/heartlib
- Models: https://huggingface.co/HeartMuLa
- Paper: https://arxiv.org/abs/2601.10547
