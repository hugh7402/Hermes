# Songsee — Audio Spectrogram & Feature Visualization

Absorbed from `songsee` skill.

## Prerequisites
Requires Go: `go install github.com/steipete/songsee/cmd/songsee@latest`

## Quick Start
```bash
songsee track.mp3
songsee track.mp3 -o spectrogram.png
songsee track.mp3 --viz spectrogram,mel,chroma,hpss,selfsim,loudness,tempogram,mfcc,flux
songsee track.mp3 --start 12.5 --duration 8 -o slice.jpg
```

## Visualization Types
| Type | Description |
|---|---|
| `spectrogram` | Standard frequency spectrogram |
| `mel` | Mel-scaled spectrogram |
| `chroma` | Pitch class distribution |
| `hpss` | Harmonic/percussive separation |
| `selfsim` | Self-similarity matrix |
| `loudness` | Loudness over time |
| `tempogram` | Tempo estimation |
| `mfcc` | Mel-frequency cepstral coefficients |
| `flux` | Spectral flux (onset detection) |

## Common Flags
| Flag | Description |
|---|---|
| `--viz` | Visualization types (comma-separated) |
| `--style` | Color palette: classic, magma, inferno, viridis, gray |
| `--width` / `--height` | Output image dimensions |
| `--start` / `--duration` | Time slice |
| `--format` | Output format: jpg or png |
| `-o` | Output file path |

## Notes
- WAV and MP3 decoded natively; other formats require ffmpeg
- Output images can be inspected with `vision_analyze` for automated analysis
