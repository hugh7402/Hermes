---
name: ai-music
description: "AI music generation, songwriting craft, audio analysis — HeartMuLa, Suno prompting, AudioCraft, spectrograms. Umbrella for all music-specific AI tools."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [music, audio, generation, ai, songwriting, suno, heartmula, audiocraft, analysis]
    related_skills: []
---

# AI Music — Generation, Craft, and Analysis

Umbrella skill for AI-powered music tools. Covers four areas:

1. **Songwriting & Suno Prompts** (see section below)
2. **HeartMuLa** — open-source music generation from lyrics + tags (see `references/heartmula.md`)
3. **AudioCraft** — MusicGen text-to-music (see `references/audiocraft.md`)
4. **Songsee** — audio spectrogram/feature visualization (see `references/songsee.md`)

## Songwriting & AI Music Prompting

### Song Structure (Pick One or Invent Your Own)

Common skeletons:
- `ABABCB` — Verse/Chorus/Verse/Chorus/Bridge/Chorus (most pop/rock)
- `AABA` — Verse/Verse/Bridge/Verse (jazz standards)
- `ABAB` — alternating verse/chorus
- `AAA` — strophic, no chorus (folk, storytelling)

Building blocks: Intro, Verse, Pre-Chorus, Chorus, Bridge, Outro.

### Rhyme, Meter, and Sound

RHYME TYPES (tight to loose): Perfect (lean/mean), Family (crate/braid), Assonance (had/glass), Consonance (scene/when), Near/slant.

INTERNAL RHYME: Rhyming within a line, not just at the ends.

METER: The rhythm of stressed vs unstressed syllables. Stressed syllables matter more than total count. Say it out loud.

### Emotional Arc and Dynamics

Think of a song as a journey. Energy mapping (rough): Intro 2-3 → Verse 5-6 → Pre-Chorus 7 → Chorus 8-9 → Bridge varies → Final Chorus 9-10.

The most powerful dynamic trick: CONTRAST. Whisper before a scream. Silence is an instrument.

### Writing Lyrics That Work

SHOW, DON'T TELL (usually). "I was sad" = flat. "Your hoodie's still on the hook by the door" = alive.

THE HOOK: The line people remember. Usually the title or core phrase. Place it where it lands hardest.

PROSODY: Stable feelings pair with resolved chords/perfect rhymes. Unstable feelings pair with wandering melodies/near-rhymes.

### Parody and Adaptation

Map the original's structure (syllables, rhyme scheme, stressed syllables). Match stressed syllables to the same beats. On long held notes, match the VOWEL SOUND. Sing your new words over the original.

### Suno AI Prompt Engineering

Formula: Genre + Mood + Era + Instruments + Vocal Style + Production + Dynamics

Describe the JOURNEY, not just the genre: "Begins as a haunting whisper over sparse piano. Gradually layers in muted brass..."

Metatags (in [brackets] in lyrics):
- Structure: [Intro] [Verse] [Pre-Chorus] [Chorus] [Bridge] [Outro]
- Vocal: [Whispered] [Belted] [Falsetto] [Harmonies] [Choir]
- Dynamics: [High Energy] [Building Energy] [Emotional Climax] [Orchestral Swell]
- SFX: [Vinyl Crackle] [Rain] [Thunder]

Phonetic tricks: Spell words as they SOUND ("through" → "thru"). ALL CAPS = louder. Vowel extension: "lo-o-o-ove".

Always use Custom Mode (separate Style + Lyrics). Style field supports up to 1000 chars in V4.5+. No artist names or trademarks.

### Workflow

1. Write concept/hook first
2. If adapting, map original structure
3. Generate raw material before structuring
4. Draft lyrics into structure
5. Read/sing aloud to fix meter
6. Build Suno style description
7. Generate 3-5 variations
8. Pick best, use Extend/Continue to build on promising sections

Expect ~3-5 generations per 1 good result.
