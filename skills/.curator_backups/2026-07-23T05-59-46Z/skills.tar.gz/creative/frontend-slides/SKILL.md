---
name: frontend-slides
description: Zero-dependency HTML presentation generator. Takes a production brief from humanize-ppt and renders beautiful, viewport-safe HTML slides with multiple style presets.
version: 1.0.0
author: zarazhangrui / dongtonghui
---

# Frontend Slides

HTML 幻灯片渲染引擎。接收 humanize-ppt 的生产简报，渲染出可直接演示的 HTML 幻灯片。支持多种风格预设（杂志风、瑞士风、极简风等）。

## 路径

- 根目录: `/opt/data/frontend-slides/`
- SKILL.md 文档: `/opt/data/frontend-slides/SKILL.md`
- 风格预设: `/opt/data/frontend-slides/STYLE_PRESETS.md`
- HTML 模板: `/opt/data/frontend-slides/html-template.md`
- 模板包: `/opt/data/frontend-slides/bold-template-pack/`
- 脚本: `/opt/data/frontend-slides/scripts/`
- 参考: `/opt/data/frontend-slides/references/`

## 使用方法

1. 先用 `humanize-ppt` 生成 AST 大纲和生产简报
2. 读取简报内容，用 `frontend-slides` 渲染成 HTML 幻灯片

## 风格预设
参考 `/opt/data/frontend-slides/STYLE_PRESETS.md` 查看可用风格。

## 要求
- 纯 HTML/CSS/JS，零外部依赖
- 浏览器可直接打开渲染后的 HTML 文件
