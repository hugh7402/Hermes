---
name: memory-manager
description: >
  Local memory management for agents. Three-tier architecture: episodic (what happened),
  semantic (what I know), procedural (how to). Compression detection, auto-snapshots,
  and semantic search. Use when agents need to detect compression risk before memory loss,
  save context snapshots, search historical memories, or track memory usage patterns.
version: 1.0.0
author: margent (marmikcfc) + Hermes adaptation
tags: [memory, organization, knowledge-base, episodic, semantic, procedural]
---

# Memory Manager

**三层记忆架构：**

### Episodic Memory（发生了什么）
- 基于时间的事件日志
- `memory/episodic/YYYY-MM-DD.md`
- "上周二做了什么？"

### Semantic Memory（我知道什么）
- 事实、概念、知识
- `memory/semantic/topic.md`
- "关于支付验证我了解什么？"

### Procedural Memory（怎么做）
- 工作流、模式、流程
- `memory/procedural/process.md`
- "如何在 Moltbook 发布？"

## 快速开始

```bash
# 初始化记忆结构
bash <skill_dir>/scripts/init.sh

# 检测压缩风险
bash <skill_dir>/scripts/detect.sh

# 搜索记忆
bash <skill_dir>/scripts/search.sh semantic "topic"

# 查看统计
bash <skill_dir>/scripts/stats.sh
```

## 命令

| 脚本 | 功能 |
|------|------|
| `init.sh` | 初始化记忆目录结构 |
| `detect.sh` | 检测压缩风险（<70%安全，70-85%警告，>85%危险） |
| `snapshot.sh` | 压缩前保存快照 |
| `organize.sh` | 迁移/组织记忆文件 |
| `search.sh` | 按类型搜索记忆 |
| `stats.sh` | 使用统计 |
| `categorize.sh` | 手动分类条目 |