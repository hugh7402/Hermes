---
name: kanban
description: "End-to-end Kanban workflow for Hermes multi-agent orchestration: routing playbook for orchestrators + pitfalls & edge cases for workers."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, routing, collaboration, workflow]
    related_skills: []
---

# Kanban — Multi-Agent Orchestration & Worker Workflow

Hermes Kanban is a durable SQLite board for multi-profile / multi-worker collaboration. This umbrella skill covers both sides:

- **Orchestrator** — decomposition playbook, task graph design, anti-temptation rules (below)
- **Worker** — lifecycle pitfalls, edge cases, workspace handling, heartbeats, blocking patterns (in `references/worker.md`)

The core lifecycle (6 steps: orient → work → heartbeat → block/complete) and the "don't do the work yourself" rule for orchestrators are auto-injected into kanban system prompts via `KANBAN_GUIDANCE`. This skill is the deeper playbook loaded on-demand.

This skill absorbs what were previously `kanban-orchestrator` (decomposition playbook) and `kanban-worker` (pitfalls and edge cases). Both are now available here.

## Orchestrator Section

> The **core worker lifecycle** (including the `kanban_create` fan-out pattern and the "decompose, don't execute" rule) is auto-injected into every kanban process via the `KANBAN_GUIDANCE` system-prompt block. This section is the deeper playbook when you're an orchestrator profile whose whole job is routing.

### Profiles are user-configured — not a fixed roster

Hermes setups vary widely. Some users run a single profile that does everything; some run a small fleet (`docker-worker`, `cron-worker`); some run a curated specialist team. There is **no default specialist roster**.

**Step 0: discover available profiles before planning.**

- `hermes profile list` — prints the table of profiles
- `kanban_list(assignee="<some-name>")` — sanity-check a single name
- **Just ask the user.**

### When to use the board (vs. just doing the work)

1. **Multiple specialists are needed.**
2. **The work should survive a crash or restart.**
3. **The user might want to interject.**
4. **Multiple subtasks can run in parallel.**
5. **Review / iteration is expected.**
6. **The audit trail matters.**

### The anti-temptation rules

- **Do not execute the work yourself.**
- **For any concrete task, create a Kanban task and assign it.**
- **Split multi-lane requests before creating cards.**
- **Run independent lanes in parallel.**
- **Never create dependent work as independent ready cards.** Use `parents=[...]`.
- **If no specialist fits, ask the user**, don't invent profile names.
- **Decompose, route, and summarize — that's the whole job.**

### Decomposition playbook

#### Step 1 — Understand the goal
#### Step 2 — Sketch the task graph
#### Step 3 — Create tasks and link (with parents)
#### Step 4 — Complete your own task
#### Step 5 — Report back to the user

See `references/orchestrator-playbook.md` for the full detailed playbook with examples, parent linking patterns, and recovery workflows.

### Goal-mode cards (persistent workers)

For open-ended cards where one turn rarely finishes the job, pass `goal_mode=True`:

```python
kanban_create(
    title="Translate the full docs site to French",
    body="Acceptance: every page translated, no English left.",
    assignee="<profile>",
    goal_mode=True,
    goal_max_turns=15,
)
```

After each worker turn, an auxiliary judge evaluates against acceptance criteria. Exhausted budget → blocked for human review.

### Recovering stuck workers

When a worker profile keeps crashing, hallucinating, or getting blocked:
1. **Reclaim** (or `hermes kanban reclaim <task_id>`) — abort and reset to `ready`
2. **Reassign** (or `hermes kanban reassign <task_id> <new-profile> --reclaim`)
3. **Change profile model** — edit profile config, then Reclaim

## Worker Section

> You're seeing this because the dispatcher spawned you with `--skills kanban-worker`. The lifecycle is auto-injected. This subsection has the deeper detail.

### Workspace handling

| Kind | What it is | How to work |
|---|---|---|
| `scratch` | Fresh tmp dir | Read/write freely; GC'd on archive |
| `dir:<path>` | Shared persistent directory | Treat like long-lived state |
| `worktree` | Git worktree | Commit work here |

### Tenant isolation

If `$HERMES_TENANT` is set, prefix memory entries with the tenant.

### Good summary + metadata shapes

See the full examples in `references/worker-patterns.md`. Key patterns:

- **Coding task:** `summary="shipped rate limiter — token bucket, 14 tests pass"`
- **Research task:** `summary="3 libraries reviewed; vLLM wins on throughput"`
- **Review task:** `summary="reviewed PR #123; 2 blocking issues found"`

### Block reasons that get answered fast

Bad: `"stuck"`. Good: one sentence naming the specific decision needed.

```python
kanban_block(reason="Rate limit key choice: IP (simple, NAT-unsafe) or user_id?")
```

### Heartbeats worth sending

Name progress: `"epoch 12/50, loss 0.31"`. Never `"still working"`.

### Retry scenarios

Check `kanban_show` for prior `runs` with `outcome` / `summary` / `error`:

- `timed_out` — the previous attempt hit max_runtime
- `crashed` — OOM or segfault
- `spawn_failed` — profile config issue, ask human via `kanban_block`
- `reclaimed` — operator archived the task

### Do NOT

- Call `delegate_task` as a substitute for `kanban_create`
- Call `clarify` (no user to answer — use `kanban_block`)
- Modify files outside `$HERMES_KANBAN_WORKSPACE`
- Complete a task you didn't finish — block it instead
