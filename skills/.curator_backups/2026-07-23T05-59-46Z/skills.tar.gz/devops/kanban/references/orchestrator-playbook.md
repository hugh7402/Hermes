# Orchestrator Full Decomposition Playbook

This is the full playbook extracted from `kanban-orchestrator`. Load this when you need the complete guide with examples for every step.

## When to use the board (vs. delegate_task)

Create Kanban tasks when any of these are true:
1. Multiple specialists needed
2. Work should survive crash/restart
3. User may want to interject
4. Multiple subtasks can run in parallel
5. Review/iteration expected
6. Audit trail matters

If none apply, use `delegate_task` or answer directly.

## Decomposition step by step

### Step 1 — Understand the goal
### Step 2 — Sketch the task graph
### Step 3 — Create tasks and link
### Step 4 — Complete your own task
### Step 5 — Report back

## Task creation with parent links

```python
t1 = kanban_create(title="research cost", assignee="<profile-A>", body="...")["task_id"]
t2 = kanban_create(title="research performance", assignee="<profile-A>", body="...")["task_id"]
t3 = kanban_create(title="synthesize", assignee="<profile-B>", parents=[t1, t2])["task_id"]
```

## Common patterns

- **Fan-out + fan-in**: N research cards, one synthesis with all as parents
- **Parallel implementation + validation**: implementer + explorer, reviewer depends on both
- **Pipeline with gates**: planner → implementer → reviewer
- **Same-profile queue**: N tasks, same profile, no deps
- **Human-in-the-loop**: kanban_block() to wait for input

## Goal-mode cards

Pass `goal_mode=True` for open-ended cards. The judge re-evaluates after each worker turn. Not done + budget remains → worker keeps going in the same session.

## Recovering stuck workers

1. Reclaim (`hermes kanban reclaim <task_id>`)
2. Reassign (`hermes kanban reassign <task_id> <new-profile> --reclaim`)
3. Change profile model

## Pitfalls

- Inventing profile names that don't exist (dispatcher silently fails)
- Bundling independent lanes into one card
- Over-linking because of wording
- Forgetting dependency links
- Reassignment vs. new task on review failure
- Argument order for `kanban_link(parent_id, child_id)`
- Don't pre-create the whole graph if shape depends on intermediate findings
- Tenant inheritance via `HERMES_TENANT`
