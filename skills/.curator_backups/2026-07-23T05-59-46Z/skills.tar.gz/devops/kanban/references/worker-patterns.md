# Worker Patterns & Pitfalls

Full detail from `kanban-worker`. Load when you need edge-case scenarios, retry diagnostics, and summary shapes.

## Workspace handling

| Kind | What it is | How to work |
|---|---|---|
| `scratch` | Fresh tmp dir, yours alone | Read/write freely; GC'd on archive |
| `dir:<path>` | Shared persistent directory | Other runs read what you write |
| `worktree` | Git worktree | If no .git, run `git worktree add` |

## Tenant isolation

Prefix memory entries with `$HERMES_TENANT`.

## Good summary + metadata shapes

### Coding task
```python
kanban_complete(
    summary="shipped rate limiter — token bucket, 14 tests pass",
    metadata={"changed_files": ["rate_limiter.py"], "tests_passed": 14},
)
```

### Coding task needing review (review-required)
Block instead of complete with `reason` prefixed `review-required:`. Drop structured metadata into a comment first.
```python
kanban_comment(body="review-required handoff:\n" + json.dumps({...}, indent=2))
kanban_block(reason="review-required: rate limiter shipped — needs eyes on user_id/IP fallback")
```

### Research task
```python
kanban_complete(
    summary="3 libraries reviewed; vLLM wins on throughput",
    metadata={"recommendation": "vLLM", "benchmarks": {"vllm": 1.0, "sglang": 0.87}},
)
```

### Review task
```python
kanban_complete(
    summary="reviewed PR #123; 2 blocking issues found",
    metadata={"pr_number": 123, "approved": False},
)
```

## Block reasons

Bad: `"stuck"` — no context. Good: one sentence naming the decision needed.

```python
kanban_block(reason="Rate limit key: IP or user_id? NAT-unsafe vs requires auth.")
```

## Heartbeats

Name progress: `"epoch 12/50"`, `"uploaded 47/120 videos"`. Not `"still working"`.

## Retry scenarios

Check prior runs for:
- `timed_out` — shorten work
- `crashed` — reduce memory
- `spawn_failed` — profile config (ask human)
- `reclaimed` — operator archived
- `blocked` — read unblock comment

## Do NOT

- Use `delegate_task` for cross-agent handoffs (use `kanban_create`)
- Use `clarify` (no user — use `kanban_block`)
- Modify files outside `$HERMES_KANBAN_WORKSPACE`
- Complete unfinished tasks

## Pitfalls

- Always `kanban_show` first (state may have changed)
- Workspace may have stale artifacts from previous runs
- Don't rely on CLI when tools are available (CLI may not be in container)
