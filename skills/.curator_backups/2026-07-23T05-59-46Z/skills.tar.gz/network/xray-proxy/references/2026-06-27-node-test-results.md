# 2026-06-27 美国三网推荐节点测试结果

## 环境

- 容器：无 systemd，无 FUSE，无 sudo
- 订阅来源：机场 VLESS 订阅（base64 编码，63 个节点）
- xray 版本：26.3.27
- 测试目标：https://www.javdb.com

## 测试方法

1. 从订阅 base64 解码提取 63 个 VLESS 链接
2. 逐个生成带完整参数（pbk/sid 必须）的 xray config
3. 启动 xray 子进程 → sleep 2s → curl --socks5 测试 → 终止进程
4. 记录 HTTP 状态码和出口 IP

## 可访问 javdb 的节点

| 编号 | 名称 | 出口 IP | HTTP 码 | 传输 | 指纹 |
|:---:|:----|:--------:|:-------:|:----:|:----:|
| N57 | 🇺🇸美国圣何塞02 三网推荐 | 134.195.101.194 | 200 | reality+vision | ios |
| N58 | 🇺🇸美国圣何塞03 三网推荐 | 134.195.101.197 | 200 | reality+vision | ios |
| N59 | 🇺🇸美国圣何塞04 三网推荐 | 134.195.101.197 | 200 | reality+vision | ios |
| N60 | 🇺🇸美国圣何塞05 三网推荐 | 134.195.101.120 | 301 | reality+vision | ios |
| N63 | 🇺🇸美国洛杉矶08 三网推荐 | 203.10.96.139 | 200 | reality+vision | ios |

## 被封节点（403/超时）

N56(美国圣何塞01), N61(圣何塞06), N62(圣何塞07) — 这些 IP 被 javdb 封禁。

## 当前持久化配置

**选用的节点**：N57 美国圣何塞02
**配置路径**：`/opt/data/xray_config.json`
**启动脚本**：`/opt/data/start_xray.sh`
**代理端口**：SOCKS5=10808, HTTP=10809
**xray 二进制**：`/tmp/xray/xray`

## 后记：N57 波动观察

2026-06-27 实测 N57 单次请求成功率约 **60%**（5 次测试：3×200 + 2×000）。javdb 搜索页和首页通常 200，但详情页（`/v/...`）连接会间歇性 `Recv failure: Connection reset by peer`。建议：
- 依赖代理的服务（javdb 搜索/字幕）加 **重试逻辑**（3 次，检查 stdout > 100 bytes）
- 如果持续失败，切换至 N58（圣何塞03）或 N63（洛杉矶08）
- 配置地址见上方各节点 IP 表
