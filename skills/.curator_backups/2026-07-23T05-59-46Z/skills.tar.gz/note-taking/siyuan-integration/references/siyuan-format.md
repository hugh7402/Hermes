# 思源笔记 .sy JSON 树格式

思源笔记使用 `.sy` 文件存储笔记内容，格式为单行 JSON。

## 节点类型

```json
{
  "ID": "20260618223115-2gaie0h",
  "Spec": "1",
  "Type": "NodeDocument",
  "Properties": {
    "id": "20260618223115-2gaie0h",
    "title": "领导对接会",
    "type": "doc",
    "updated": "20260618223700"
  },
  "Children": [...]
}
```

| Type | 含义 | 关键属性 |
|------|------|---------|
| `NodeDocument` | 文档根节点 | `title`, `updated` |
| `NodeParagraph` | 段落 | 子节点 `NodeText.Data` |
| `NodeText` | 纯文本 | `Data` 为文本内容 |
| `NodeHeading` | 标题 | `HeadingLevel` (1-based) |
| `NodeList` | 列表容器 | 内含 `NodeListItem` |
| `NodeListItem` | 列表项 | `ListData.Typ`: 1=有序, 3=无序 |
| `NodeBlockquote` | 引用块 | 内含段落 |
| `NodeCodeBlock` | 代码块 | `CodeBlockInfo` 为语言 |
| `NodeTable` | 表格 | 复杂嵌套结构 |

## 目录结构

```
workspace/data/
├── {box_id}/              ← 笔记本（如 20210808180117-czj9bvb）
│   ├── .siyuan/conf.json  ← 笔记本名
│   ├── {doc_id}.sy        ← 顶层文档
│   └── {doc_id}/          ← 子文档目录
│       └── {child_id}.sy
```

## 解析要点

1. **递归遍历** — 文档是嵌套树，需递归 `Children`
2. **NodeList → NodeListItem** — 两层嵌套，ListItem 内才是文本
3. **标题层级** — `NodeHeading.HeadingLevel` + 1 = Markdown `#` 数量
4. **文本提取** — 遍历到 `NodeText` 取 `Data`，累加所有同级文本
5. **更新检查** — 用 `doc_id` + `.siyuan_extracted` 文件做去重
