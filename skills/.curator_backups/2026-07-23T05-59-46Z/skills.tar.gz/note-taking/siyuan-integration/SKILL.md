---
name: siyuan-integration
description: 思源笔记 → Obsidian 知识库自动同步。.sy JSON 树提取、层级中文文件名、00-INBOX/ 入库。
---

# 思源笔记集成

将思源笔记的数据目录（`.sy` JSON 格式）提取为 Markdown，保留原始文字存入 Obsidian 的 `00-INBOX/` 目录。

## 触发条件

- 用户提到思源笔记、SiYuan、`.sy` 格式
- 需要配置思源 → Obsidian 自动同步
- 思源笔记提取或入库问题
- 思源笔记语音文件（NodeAudio）转写

## 知识库分层（用户偏好 — 注意历史）

思源笔记内容多为会议纪要、日常记录。用户（艾玛）此会话中经历了多次调整，**最终确定三个来源统一为同一套知识库**：

| 目录 | 内容 | 增强 | 检索/关联发现 |
|------|------|:----:|:------------:|
| `concepts/` | WebChat 文档 | ✅ note_enhance | ✅ |
| `00-INBOX/` | 思源笔记 | ✅ note_enhance | ✅ |
| `01-WeiXin/` | 微信文档 | ✅ note_enhance | ✅ |

*方向变更历史：先要求 00-INBOX 不做增强、不参与检索 → 后又改为统一做、统一检索。`note_enhance.py` 的 `get_all_notes()` 已改为跨目录搜索三个文件夹。*

**思源笔记写入 00-INBOX/ 时调用 note_enhance 增强**（传绝对路径）。  
**关联发现范围**：`get_all_notes()` 跨目录搜索 `concepts/` + `01-WeiXin/` + `00-INBOX/` 下的全部笔记。

## 架构

```
思源 App（手机/电脑）→ 同步到 NAS
        ↓
/opt/data/INBOX_FILES/workspace/data/  ← 思源数据目录（.sy 文件）
        ↓ cron: 0 17 * * *
/opt/data/siyuan_sync.py
  ├── 构建层级标题树（父标题-子标题）
  ├── 层级中文文件名（如 陕西智慧民政项目-领导对接会.md）
  ├── 跳过帮助文档（关键词过滤）
  ├── 语音节点 NodeAudio → SiliconFlow 转写
  └── → 00-INBOX/ Markdown → note_enhance 增强（YAML frontmatter）
```

## 关键文件

| 文件 | 角色 |
|------|------|
| `/opt/data/siyuan_sync.py` | 主脚本：提取 + 转语音 + note_enhance 增强 + 入库 |
| `/opt/data/INBOX_FILES/` | 思源数据目录（用户挂载） |
| `/opt/data/.siyuan_extracted` | 已提取记录（防重复） |
| `VAULT/00-INBOX/` | 思源笔记最终存放位置 |

## 用户偏好（已嵌入脚本）

1. **层级中文文件名** — 按文档树层级命名（如 `陕西智慧民政项目-领导对接会.md`）
2. **存入 `00-INBOX/`** — 不与 `concepts/` 混合
3. **跳过帮助文档** — 思源自带的帮助文档（"请从这里开始"等 60+ 篇）不提取
4. **所有来源均做 AI 增强** — 00-INBOX/ 思源笔记同样调用 note_enhance 生成 YAML frontmatter（摘要+标签+关联发现）
5. **语音节点自动转写** — NodeAudio 遇到 mp3 文件自动调用 SiliconFlow 转写为文字

## 思源 .sy 格式

`.sy` 文件是 JSON 树结构，`node_to_md()` 覆盖以下节点类型：

| 节点类型 | 处理方式 |
|---------|---------|
| `NodeDocument` | 标题 → `# 标题` |
| `NodeHeading` | 标题级别 → `# → ## → ###` |
| `NodeParagraph` | 文字内容 |
| `NodeListItem` | 列表项（有序/无序） |
| `NodeBlockquote` | 引用块 → `>` |
| `NodeCodeBlock` | 代码块 → ``` |
| `NodeTable` | 表格文本 |
| `NodeAudio` | **语音转文字**（见下方） |
| 其他未识别节点 | **兜底检查**是否有图片/视频/附件引用并标记 |

### NodeAudio 语音转文字

2026-06-23 新增：`node_to_md()` 识别 `NodeAudio` 类型，Data 字段包含 `<audio src="assets/xxx.mp3">` HTML 标签。

**处理流程：**
1. 正则提取 `src="([^"]+)"` 获取音频文件路径
2. 路径以 `assets/` 开头 → 拼接 `{SIYUAN_DATA}/assets/xxx.mp3`
3. 调用 SiliconFlow SenseVoiceSmall API 转写
4. 输出格式：`> 🎤 语音留言转写：*转写文字*`
5. 转写失败输出：`> 🎤 语音文件：{src}（转写失败）`

**技术细节：**
- 转写 API：`POST https://api.siliconflow.cn/v1/audio/transcriptions`
- 模型：`FunAudioLLM/SenseVoiceSmall`
- 超时：30s
- API Key：从 `.env` 读取 `SILICONFLOW_API_KEY`（`os.open` FD 绕过 Hermes 掩码）

**关键函数**（在 `siyuan_sync.py` 中）：
- `get_api_key()` — 从 `.env` 读取指定 Key（支持所有 Key，传入 env_name 参数）
- `transcribe_audio(mp3_path)` — curl POST 转写语音，返回文字或 None

### 兜底媒体处理

对于未识别的节点类型，脚本会检查 `Data` 字段是否包含 `src="..."` 引用（图片、视频、PDF、压缩包等常见附件），匹配则输出 `> 📎 附件：[文件名](路径)`。

## 陷阱

### 以前做过增强的笔记需要手动还原

如果之前 siyuan_sync.py 配置了 note_enhance（2026-06-23 之前），已入库的思源笔记带有 YAML frontmatter。切换"不做增强"模式后需：
1. 清空 `00-INBOX/` 目录
2. 清空 `.siyuan_extracted` 记录
3. 重新跑一次 `siyuan_sync.py` 全量提取

### 帮助文档过滤

思源笔记库包含 60+ 篇自带帮助文档。关键词列表 `SKIP` 在 `siyuan_sync.py` 中维护，新增思源版本时可能需要更新。

### note_enhance.py 已支持绝对路径

note_enhance.py 的 main() 现在支持绝对路径参数（2026-06-23 修改）。如果传来的是绝对路径（如 `Path.is_absolute()` 为 True），直接使用，不再拼接 `VAULT`。其他脚本调用时可以传绝对路径，无需 cwd 技巧。

## Cron

```
job_id: 5652f5032fe5
schedule: 0 17 * * *（每天 17:00）
script: /opt/data/siyuan_sync.py
mode: agent（2026-06-22 从 no_agent 改为 agent，避免调度器 120s 硬超时）
```
