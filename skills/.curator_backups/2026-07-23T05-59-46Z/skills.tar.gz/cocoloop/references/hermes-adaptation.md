# Cocoloop on Hermes — Mapping Guide

Cocoloop was designed for OpenClaw/Claude Code/Molili platforms that use file-based skill installation. On Hermes, skill management is tool-based via `skill_manage`.

## URL Installation Workflow (Hermes adaptation)

```
1. Download: curl -sL <url> -o /tmp/skill.zip
2. Inspect: python3 -c "import zipfile; z=zipfile.ZipFile('/tmp/skill.zip'); z.infolist()"
3. Evaluate: Read SKILL.md to assess usefulness
4. Install:
   - Create skill: skill_manage(action='create', name='<name>', content='...SKILL.md content...')
   - Add scripts: skill_manage(action='write_file', name='<name>', file_path='scripts/<file>.py', ...)
   - Add refs: skill_manage(action='write_file', name='<name>', file_path='references/<file>.md', ...)
5. Install deps: uv pip install <package> or pip install <package>
6. Set env vars: Add to .env
7. Verify: Run a quick test
```

## Key differences from OpenClaw

| Aspect | OpenClaw/Claude Code | Hermes |
|--------|---------------------|--------|
| Install command | `claude skills install` / `npx clawhub@latest install` | `skill_manage(action='create')` |
| Script placement | `~/.claude/skills/<name>/scripts/` | `~/skills/<name>/scripts/` via `skill_manage(action='write_file')` |
| Platform detection | Environment variables | Not needed — all skills managed via skill tools |
| Safety check | Cocoloop Safe Check (BSS) | Trust-based; inspect code manually |

## Pitfalls

- Zip files from Windows may have backslash path separators (`lib\\file.py`). Fix with `mv` or Python rename.
- Always test API before installing (curl / Python) to confirm the service works.
- `install.sh` from zip packages is for OpenClaw — ignore it on Hermes.
