---
name: webdav-file-manager
description: 给任何 WebDAV 云存储搭建暗黑主题网页文件管理器——浏览器里浏览、下载。含 rclone serve webdav + 自包含 HTML 前端 + Docker 网络排查。
trigger: 用户说 "可视化文件管理"、"网页版文件管理器"、"浏览器浏览 PikPak/云盘"、"WebDAV 文件浏览器"
---

# WebDAV 网页文件管理器

为 WebDAV 源（PikPak、NextCloud、ownCloud 等）快速搭建一个可浏览可下载的暗黑主题文件管理器。

## 流程

### 1. 安装 rclone（如果未安装）

```bash
curl -fsSL https://rclone.org/install.sh | bash
# 或下载静态二进制
wget -q https://downloads.rclone.org/v1.74.3/rclone-v1.74.3-linux-amd64.zip
unzip rclone-v1.74.3-linux-amd64.zip
cp rclone-v1.74.3-linux-amd64/rclone /tmp/rclone
```

### 2. 配置 rclone WebDAV 远程端

```bash
# 交互式配置，或直接写配置文件 ~/.config/rclone/rclone.conf
rclone config create <remote-name> webdav \
  url=<WebDAV_URL> \
  vendor=other \
  user=<用户名> \
  pass=<rclone加密后的密码>
```

> **密码加密**：`rclone obscure "明文密码"` 得到加密串，直接写入 config。

### 3. 创建管理脚本（pikpak.sh）

核心命令：

```bash
# 启动 WebDAV 服务 (端口 8080)
rclone serve webdav <remote-name>:/ \
  --addr :8080 \
  --vfs-cache-mode full \
  --dir-cache-time 300s

# 启动静态文件浏览器 (端口 8081)
cd <静态目录> && python3 -m http.server 8081
```

### 4. 自包含 HTML 文件浏览器

写一个 index.html，核心原理：

- 通过 **WebDAV 的 PROPFIND 方法** 列出目录
- 发送 `Depth: 1` 请求头 + XML body 列举文件
- 解析 PROPFIND 的 XML 响应提取：displayname, getcontentlength, getlastmodified, resourcetype
- 区分目录（点击进入）/ 文件（点击下载）
- 面包屑导航显示当前位置
- 下载直接用 `<a href>` 指向 WebDAV 接口

**关键代码模式**（浏览器端 JavaScript）：

```javascript
const BASE = 'http://<宿主机IP>:8080';

async function listDir(path) {
  const resp = await fetch(BASE + path, {
    method: 'PROPFIND',
    headers: { 'Depth': '1', 'Content-Type': 'application/xml' },
    body: '<?xml version="1.0"?><D:propfind xmlns:D="DAV:">' +
          '<D:prop><D:displayname/><D:getcontentlength/>' +
          '<D:getlastmodified/><D:resourcetype/></D:prop></D:propfind>'
  });
  const xmlText = await resp.text();
  // 解析 XML...
}
```

> **注意**：XML 命名空间解析时，`querySelector` 中的冒号需要转义：`querySelector('D\\:response, response')`

### 5. 启动服务

```bash
bash <script-name>.sh start
```

### 6. 验证

```bash
# 检查端口是否在监听
curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/  # → 200
curl -s -o /dev/null -w '%{http_code}' http://localhost:8081/  # → 200
```

## Docker 容器环境特别注意

### ⚠️ 先确定是 bridge 还是 host 网络模式

不要只看 docker-compose.yml 写的 `network_mode`。**实际运行模式可能不同**。

**检测方法**（从容器内部）：

```bash
# 方法 1: 检查 eth0 MAC 地址
cat /sys/class/net/eth0/address
# 输出类似 02:42:ac:12:00:02 → 02:42 开头 = Docker bridge 网络
# 如果是 host 模式，MAC 会是宿主机网卡的真实 MAC

# 方法 2: 检查 /etc/hosts 中的 IP
cat /etc/hosts | grep $(hostname)
# bridge → 172.x.x.x / 10.x.x.x（Docker 子网 IP）
# host → 宿主机真实内网 IP（如 192.168.x.x）
```

**判断结论**：
- MAC `02:42:xx:xx:xx:xx` + IP `172.x.x.x` → **bridge 网络**，端口仅在容器内部可见，宿主机和局域网不可达
- 宿主机真实 MAC + IP → **host 网络**，端口直接暴露在宿主机

### bridge 网络下：端口映射

如果是 bridge 网络，需要在 docker run 时加 `-p` 参数，或者在 docker-compose.yml 中加 `ports` 段：

```yaml
ports:
  - "23456:23456"   # WebDAV
  - "23457:23457"   # Web UI
```

或者让用户从宿主机执行：
```bash
docker restart hermes   # 需先改 compose 加 ports
```

### host 网络下：宿主机防火墙

如果确实是 `network_mode: host` 但局域网仍然访问不了，一般是宿主机防火墙拦截：

- **检查宿主机防火墙**（需在宿主机上执行）：
  ```bash
  sudo ufw status        # ufw 防火墙
  sudo firewall-cmd --list-ports  # firewalld
  ```
- **放行端口**：
  ```bash
  sudo ufw allow <端口>/tcp
  sudo firewall-cmd --add-port=<端口>/tcp --permanent
  ```

### 端口重映射（防火墙拦截时的兜底方案）

当标准端口（8080/8081）被防火墙拦截且无法修改防火墙规则时：

1. **改管理脚本中的端口号**
   - `rclone serve webdav --addr :<新端口>`
   - `python3 -m http.server <新端口>`

2. **改 index.html 中的 BASE URL**
   ```javascript
   const BASE = 'http://' + window.location.hostname + ':<新WebDAV端口>';
   ```

3. **验证两个端口都在监听**
   ```bash
   curl -s -o /dev/null -w '%{http_code}' http://localhost:<新WebDAV端口>/  # → 200
   curl -s -o /dev/null -w '%{http_code}' http://localhost:<新WebUI端口>/   # → 200
   ```

### SSH 隧道（当防火墙不可控时的终极兜底）

在客户端电脑上运行：
```bash
ssh -L <本地WebUI端口>:localhost:<容器WebUI端口> -L <本地WebDAV端口>:localhost:<容器WebDAV端口> user@<宿主机IP>
```
然后浏览器打开 `http://localhost:<本地WebUI端口>`

### 容器内查宿主机防火墙有限制

`iptables`/`nft`/`ufw` 通常不可用或看不到宿主机规则。判断方法：
- 容器内 `curl localhost:端口` 正常 → 服务没问题
- 局域网其他机器访问不了 → 宿主机防火墙或端口未映射（见上方检测方法）

## 管理脚本模板（pikpak.sh 模式）

```bash
#!/usr/bin/env bash
RCLONE="/tmp/rclone"
REMOTE="<remote-name>"
LOCAL="/opt/data/<name>"
PIDFILE="/tmp/<name>_webdav.pid"

case "${1:-help}" in
  start)
    nohup ${RCLONE} serve webdav "${REMOTE}:/" --addr :8080 [...] &
    cd "$LOCAL" && nohup python3 -m http.server 8081 &
    ;;
  stop)
    kill $(cat /tmp/*.pid 2>/dev/null) 2>/dev/null; rm -f /tmp/*.pid
    ;;
  status)
    echo "WebDAV: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/ 2>/dev/null || echo 'off')"
    echo "Web UI: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8081/ 2>/dev/null || echo 'off')"
    ;;
  ls|tree|get|put|sync)
    # 委托给 rclone
    ;;
esac
```

## 支持文件

- `templates/webdav-browser.html` — 自包含暗黑主题文件浏览器 HTML。使用 `{{TITLE}}` 和 `{{WEBDAV_PORT}}` 作为占位符，用前替换即可。
- `references/pikpak-setup.md` — PikPak 的具体 WebDAV 配置参考（端点、密码处理、已知特性）。

## 已知问题

- PikPak 海外服务器延迟较高，首次加载目录可能慢 3-5 秒
- WebDAV 不支持分片上传大文件（>2GB 建议用 rclone copy）
- Docker 容器无 `/dev/fuse`，无法 `rclone mount` 成本地盘
