# PikPak 具体配置参考

## WebDAV 端点

| 项目 | 值 |
|------|-----|
| **URL** | `http://dav.mypikpak.com:80` |
| **协议** | 纯 HTTP（非 HTTPS） |
| **验证** | Basic Auth（用户名 + 密码） |
| **rclone 配置名** | `pikpak` |
| **vendor** | `other` |

## 密码处理

rclone 配置中的密码需预先加密：

```bash
rclone obscure "明文密码"
```

加密后的字符串直接写入 `~/.config/rclone/rclone.conf` 的 `pass` 字段。

## 服务端口（当前配置）

| 服务 | 端口 | 说明 |
|------|------|------|
| WebDAV API | **23456** | rclone serve webdaw（原 8080，因防火墙拦截改） |
| Web UI | **23457** | Python http.server + index.html（原 8081，因防火墙拦截改） |

> 端口变更后，`index.html` 中的 `BASE` URL 需要同步更新：
> ```javascript
> const BASE = 'http://' + window.location.hostname + ':23456';
> ```

## 已知特性

- 目录列表包含中英文混合文件名，排序按 `localeCompare('zh-CN')`
- 部分嵌套目录在 tree 命令下报 `directory not found` — 可能是 PikPak 侧的文件同步延迟
- 延迟偏高（境外服务器），建议 `--dir-cache-time 300s` 减少请求
- 大文件下载建议用 `rclone copy` 而非浏览器直接下载（浏览器下载不稳定）
- WebDAV 端口和 Web UI 端口被防火墙拦时，需同时更新两个配置位置（脚本的端口号 + index.html 的 BASE URL）

## 管理脚本位置

`/opt/data/pikpak.sh` — 已在用户环境部署运行中。

## 已知陷阱

1. **docker-compose.yml 写 host 但实际可能不是** — 检查 `/sys/class/net/eth0/address`：`02:42` 开头 = Docker bridge 网络，需要 `-p` 端口映射
2. **改端口容易漏改 index.html** — 端口改了但 JS 的 BASE 还是旧的 WebDAV 端口，导致前端无法加载目录
