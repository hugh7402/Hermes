# LibreOffice 安装指南（无 root 环境，便携版）

## 关键发现

- **官方已不再提供 AppImage**（26.x 起），需下载 `.deb.tar.gz` 解压使用
- **`soffice`（带 oosplash）会因缺 `libXinerama.so.1` 崩溃**，改用 `soffice.bin` 直调
- **必须设置 `SAL_USE_VCLPLUGIN=svp`** 才能在无 X11 环境跑 headless 模式

## 下载（推荐国内镜像）

官方源从国内下载极慢（25 分钟仅 15%），用中科大镜像秒下：

```bash
# 先查最新版本号
curl -s https://download.documentfoundation.org/libreoffice/stable/ | grep -oP 'href="\K[0-9]+\.[0-9]+\.[0-9]+' | sort -V | tail -1

# 中科大镜像（208MB，国内快）
MIRROR="https://mirrors.ustc.edu.cn/tdf/libreoffice/stable"
VER="26.2.4"
curl -L -o libreoffice.tar.gz \
  "$MIRROR/$VER/deb/x86_64/LibreOffice_${VER}_Linux_x86-64_deb.tar.gz"
```

## 无 root 安装

`.deb.tar.gz` 内是 `.deb` 包结构，需要两步提取：

```bash
# 1. 解压 tar.gz
mkdir -p /opt/data/apps/libreoffice
tar xzf libreoffice.tar.gz -C /opt/data/apps/libreoffice

# 2. 从 .deb 包提取二进制
DEBS_DIR=$(find /opt/data/apps/libreoffice -name "DEBS" -type d | head -1)
INSTALL_DIR="/opt/data/apps/libreoffice/install"
mkdir -p "$INSTALL_DIR"
for deb in "$DEBS_DIR"/*.deb; do
    dpkg-deb -x "$deb" "$INSTALL_DIR"
done
```

## Wrapper 脚本

创建 `/opt/data/apps/libreoffice/lo_wrapper`：

```bash
#!/bin/bash
SOFFICE=/opt/data/apps/libreoffice/install/opt/libreoffice26.2/program/soffice.bin
export SAL_USE_VCLPLUGIN=svp
exec "$SOFFICE" --headless --norestore "$@"
```

关键点：
- 用 `soffice.bin` 而非 `soffice`（跳过 oosplash，避免 X11 依赖报错）
- `SAL_USE_VCLPLUGIN=svp` 强制 headless 模式
- `--norestore` 跳过文档恢复提示

## 验证

```bash
chmod +x /opt/data/apps/libreoffice/lo_wrapper
/opt/data/apps/libreoffice/lo_wrapper --version
# → LibreOffice 26.2.4.2 ...

# 测试转换
echo "hello" > /tmp/test.txt
/opt/data/apps/libreoffice/lo_wrapper --convert-to pdf --outdir /tmp /tmp/test.txt
```

## 常见问题

| 错误 | 原因 | 解决 |
|------|------|------|
| `error while loading shared libraries: libXinerama.so.1` | oosplash 链接了 X11 | 用 `soffice.bin` 替代 `soffice` |
| `exit code 81` | 无 DISPLAY 环境变量 | 加 `export SAL_USE_VCLPLUGIN=svp` |
| `Could not find platform independent libraries` | 无害警告，可忽略 | — |
| `Ignoring hdmx/VDMX table` | 字体表警告，无影响 | — |
