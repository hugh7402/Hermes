---
name: proxy-from-subscription
title: Proxy from V2Ray/VLESS Subscription
description: Set up a SOCKS5/HTTP proxy from a V2Ray subscription link (VLESS) in a container/headless environment without root access. Includes node parsing, reality/WS config generation, and batch testing.
---

# Proxy from VLESS/V2Ray Subscription

Set up xray as a SOCKS5+HTTP proxy from a V2Ray subscription link (base64-encoded VLESS links).

## Trigger

User provides a V2Ray subscription URL (ending in `/api/v1/...`, `clash.meta`, etc.) or a file containing one, and says "set up proxy" / "帮我搭代理".

## Steps

### 1. Fetch and decode subscription

```bash
curl -sL "$SUB_URL" | base64 -d 2>/dev/null
```

Extract VLESS links: `re.findall(r'vless://[^\s\r\n]+', decoded)`

### 2. Parse VLESS link

Each VLESS link format:
```
vless://UUID@HOST:PORT?type=tcp|ws&security=none|tls|reality&flow=xtls-rprx-vision&fp=ios|chrome|safari&sni=SNI&pbk=PUBLIC_KEY&sid=SHORT_ID&host=WS_HOST&path=WS_PATH#NAME
```

Key parameters to extract:
- `host`, `port` — server address
- `type` — `tcp` or `ws` (WebSocket)
- `security` — `tls`, `reality`, or `none`
- `flow` — `xtls-rprx-vision` (for reality)
- `fp` — fingerprint (ios, chrome, safari)
- `sni` — Server Name Indication (for reality/TLS)
- `pbk` — publicKey (REQUIRED for reality)
- `sid` — shortId (for reality)
- `host` — WS host header (for WS TLS)
- `path` — WS path (for WS)

### 3. Build xray config

**For reality (recommended, harder to detect):**
```python
streamSettings = {
    "network": "tcp",
    "security": "reality",
    "realitySettings": {
        "serverName": sni or host,
        "fingerprint": fp or "chrome",
        "show": False,
        "publicKey": pbk,    # REQUIRED — never omit
        "shortId": sid or ""
    }
}
```

**For WS + TLS:**
```python
streamSettings = {
    "network": "ws",
    "security": "tls",
    "tlsSettings": {
        "serverName": sni or ws_host,
        "fingerprint": fp or "chrome",
        "allowInsecure": False
    },
    "wsSettings": {
        "path": path or "/",
        "headers": {"Host": ws_host} if ws_host else {}
    }
}
```

Always include both SOCKS5 (10808) and HTTP (10809) inbounds for flexibility.

### 4. Download xray binary

From GitHub releases (if accessible) or Gitee mirror:
```bash
# Check arch
uname -m  # x86_64 → amd64, aarch64 → arm64

# From GitHub
curl -sL "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip"

# From Gitee mirror (for China networks)
curl -sL "https://gitee.com/hagb/xray-core/releases/latest/download/Xray-linux-64.zip"
```

Unzip to a writable directory like `/tmp/xray/`.

### 5. Test nodes

Write a test script that:
1. Kills any existing xray (`kill $(cat /opt/data/xray.pid)` — NOT `pkill -f xray` which kills itself)
2. Starts xray with target node config
3. Waits 2s for startup
4. Tests: `curl -s --socks5 127.0.0.1:10808 https://target-site.com`
5. Check exit code and HTTP status code
   - `000` means connection failed (config error or node down — check parameters!)
   - `200` = working
   - `301/302` = redirect (usually still working)
   - `403` = IP blocked by target site

**IMPORTANT**: 000 usually means config is wrong (missing pbk, wrong sni, etc.), NOT that the site blocked you.

### 6. Persist as background daemon

```bash
nohup /tmp/xray/xray run -c /opt/data/xray_config.json \
    > /opt/data/xray_stdout.log 2>&1 &
echo $! > /opt/data/xray.pid
```

Create a start script (`start_xray.sh`) with PID management.

## Pitfalls

- **Reality needs pbk**: The `publicKey` (pbk) parameter from the VLESS URL is MANDATORY. Without it xray fails with `empty "password"` error. Also include `shortId` (sid).
- **pkill xray kills itself**: When running pkill -f xray in terminal, the pkill command itself may contain "xray" in its process name and die. Use `kill $(cat /opt/data/xray.pid)` or kill specific PIDs.
- **Node naming**: Decode URL fragment (#) with `urllib.parse.unquote()` to get readable node names (e.g., "🇺🇸美国圣何塞01 | 三网推荐").
- **Subscription links may have CRLF**: VLESS links are separated by `\r\n` — use `re.findall(r'vless://[^\s\r\n]+', decoded)`.
- **Some nodes work intermittently**: Test multiple times if first attempt fails (especially WS/TLS nodes behind CDN).
- **Gateway restart block**: `hermes gateway restart` refuses to run from inside the gateway process. User must run it from a terminal outside Hermes.

## Verification

```bash
# Check exit IP
curl -s --socks5 127.0.0.1:10808 https://httpbin.org/ip

# Test target site (follow redirects)
curl -sL -o /dev/null -w '%{http_code}' --socks5 127.0.0.1:10808 \
  -A 'Mozilla/5.0' https://target-site.com

# Also HTTP proxy works
curl -sL -o /dev/null -w '%{http_code}' -x http://127.0.0.1:10809 \
  -A 'Mozilla/5.0' https://target-site.com
```
