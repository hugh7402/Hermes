---
name: hermes-provider-management
description: "Manage Hermes agent providers — list, switch, add custom API backends (百炼, 硅基流动, etc.), and troubleshoot provider-level issues."
version: 1.0.0
author: Emma + Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, provider, configuration, model-selection, bailian, siliconflow]
    related_skills: [hermes-agent]
---

# Hermes Provider Management

## Overview

Hermes uses a layered provider system:
1. **Built-in providers** — `deepseek`, `alibaba`, `zai`, `openrouter`, `anthropic`, etc. Defined in `hermes_cli/models.py` via `CANONICAL_PROVIDERS`.
2. **Plugin providers** — `plugins/model-providers/<name>/` can extend the list at startup.
3. **`custom` provider** — designed for Ollama/local endpoints, NOT general OpenAI-compatible APIs.

Each provider profile declares: `base_url`, `env_vars` (which `.env` key to read for API key), model whitelist (in `hermes_cli/models.py`), and aliases.

## Switching Day-to-Day Model

The daily conversation model is controlled by `config.yaml`:

```bash
hermes config set model.default "glm-5.2"
hermes config set model.provider "deepseek"
hermes config set model.base_url "https://..."
hermes config set model.api_key "sk-..."
hermes gateway restart
```

**⚠️ Critical: Gateway restart from outside only.** Hermes blocks `hermes gateway restart` when called from within the gateway process (prevents loop). Must be run from a real terminal.

## Adding a Custom Provider (Plugin)

When built-in providers don't match your API (wrong URL, wrong env var, missing model in whitelist):

### Step 1: Create plugin directory

```
~/.hermes/plugins/model-providers/<name>/
├── plugin.yaml
└── __init__.py
```

### Step 2: plugin.yaml

```yaml
name: bailian-provider
kind: model-provider
version: 1.0.0
description: 阿里百炼 DashScope 国内版
author: Emma
```

### Step 3: __init__.py

```python
"""阿里百炼 DashScope (国内版) provider profile."""

from providers import register_provider
from providers.base import ProviderProfile

bailian = ProviderProfile(
    name="bailian",
    aliases=("bailian", "aliyun-bailian", "dashscope-cn"),
    env_vars=("BAILIAN_API_KEY",),
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

register_provider(bailian)
```

### Step 4: Point Hermes at it

```bash
hermes config set model.default "glm-5.2"
hermes config set model.provider "bailian"
hermes config set model.base_url ""         # empty = use plugin default
hermes config set model.api_key "sk-..."    # or let plugin read env var
hermes gateway restart
```

## Known Provider Quirks

### alibaba (DashScope)
- **Built-in URL**: `dashscope-intl.aliyuncs.com` (国际版) — NOT `dashscope.aliyuncs.com` (国内版)
- **Built-in env var**: `DASHSCOPE_API_KEY` — NOT `BAILIAN_API_KEY`
- **Model whitelist**: only lists `glm-5` (not `glm-5.2`). However, the whitelist is cosmetic — unlisted models may still work. If gateway reverts on restart, the real cause is likely a URL/auth mismatch, not the missing model name.

### deepseek
- **Base URL**: `api.deepseek.com` — NOT `api.siliconflow.cn`
- Using deepseek provider with a non-DeepSeek URL will cause gateway to revert config on restart.
- Use a custom plugin for alternative endpoints serving DeepSeek models.

### custom
- **Designed for**: Ollama/local OpenAI-compatible endpoints
- **NOT suitable for**: 百炼, 硅基流动, or other cloud APIs with different auth patterns
- Has `think=False` and `num_ctx` Ollama-specific logic. May work for simple OpenAI-compatible endpoints but not guaranteed.

### zai (Z.AI / GLM)

- **Provider slug**: `zai` (aliases: `glm`, `zhipu`, `z-ai`, `z.ai`)
- **Env var**: `GLM_API_KEY` (also `ZAI_API_KEY`, `Z_AI_API_KEY`)
- **Transport**: `openai_chat` — full OpenAI-compatible API
- **Endpoint auto-detection**: Probes 4 endpoints with model-prefix matching:
  - `global` — `api.z.ai/api/paas/v4` (prefix: `glm-5`)
  - `cn` — `open.bigmodel.cn/api/paas/v4` (prefix: `glm-5`)
  - `coding-global` — `api.z.ai/api/coding/paas/v4` (prefix: `glm-5.1`, `glm-5v-turbo`, `glm-4.7`)
  - `coding-cn` — `open.bigmodel.cn/api/coding/paas/v4` (prefix: `glm-5.1`, `glm-5v-turbo`, `glm-4.7`)
- **Override**: Set `GLM_BASE_URL` in `.env` to skip auto-detection and use a fixed endpoint
- **glm-5.2 support**: `glm-5.2` matches the `glm-5` prefix → routes to `cn` endpoint automatically. Works despite not being in the model whitelist.
- **glm-5.2 is a reasoning model**: Spends 500+ tokens on `reasoning_content` before outputting `content`. Latency ~20s even for simple queries. Ensure Hermes has adequate `max_tokens`.
- **Full details**: See `references/zai-provider-details.md` for endpoint auto-detection, glm-5.2 behavioral profile, and API testing script.

## Model Switching Checklist

When the user asks to switch models:
1. **Identify the provider**: Built-in? Or need custom plugin?
2. **Prefer built-in providers**: The model whitelist in `hermes_cli/models.py` is **cosmetic only** — for autocomplete/display. It does NOT block unlisted models. If the provider's API supports a model, Hermes will use it regardless of whitelist. Only create a custom plugin when the provider's `base_url`, `transport`, or `env_vars` genuinely don't match your API.
3. **Check env var name**: Does `.env` have the right key? (`DASHSCOPE_API_KEY` vs `BAILIAN_API_KEY` vs `GLM_API_KEY` vs `SILICONFLOW_API_KEY`)
4. **Test API directly first**: Before touching Hermes config, verify the API key + endpoint + model combo works with a raw Python `urllib.request` call. Catches auth/endpoint issues before they become "Hermes silently reverted" mysteries.
5. **Write config**: `hermes config set model.default/provider/base_url/api_key`
6. **Restart gateway**: Must be from outside terminal
7. **Verify**: Send test message, check `hermes config` after restart

## Common Pitfalls

1. **Gateway silently reverts config on restart** — usually a URL/auth mismatch (wrong base_url for provider, wrong env var name, API key not in `.env`). The model whitelist is cosmetic and does NOT cause reverts. Always test the API directly with `urllib.request` before concluding Hermes is the problem.
2. **Creating custom plugins unnecessarily** — custom provider plugins are fragile and should be a LAST resort. Built-in providers (`zai`, `deepseek`, `alibaba`) often work for models not in their whitelist. The whitelist only controls autocomplete display, not runtime access. Try the built-in provider first.
3. **`model.api_key` persists after provider change** — if you switch from `deepseek` to `zai` but forget to update `api_key`, the old key may cause auth failures. Always clear/reset all four fields together.
4. **Custom provider not discovered** — plugins are loaded lazily at Hermes startup. `CANONICAL_PROVIDERS` static list won't show them; they appear only after `get_provider_profile()` / `list_providers()` runs.
5. **Gateway cannot self-restart** — the error `Refusing to restart the gateway from inside the gateway process` is intentional. Must run from terminal.
6. **Reasoning models need high max_tokens** — models like `glm-5.2` spend most tokens on `reasoning_content` before outputting. With low `max_tokens`, they may produce only reasoning and cut off the actual reply. Test with `max_tokens: 2000` to see full output.

## Verification Checklist

- [ ] `hermes config` shows correct `model.default`
- [ ] `hermes config` shows correct `model.provider`
- [ ] API key matches provider's expected env var
- [ ] Direct API test succeeds (raw Python `urllib.request` call)
- [ ] Gateway restart completed without silent revert
- [ ] Test message confirms model is active
