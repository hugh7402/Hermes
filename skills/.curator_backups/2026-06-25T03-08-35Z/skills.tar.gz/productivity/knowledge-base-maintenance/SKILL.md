---
name: knowledge-base-maintenance
description: "知识库健康运维：断链修复、巡检报告、RSS政策监控入库。覆盖 Obsidian vault 的日常维护和自动化。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [knowledge-base, obsidian, maintenance, vault-health, wikilinks]
    category: productivity
---

# 知识库运维

覆盖 Obsidian 知识库的日常维护、健康巡检和自动化入库。

## 适用场景

- 知识库健康检查（断链、孤立页面、frontmatter 完整性）
- 批量修复 Wikilink 断链
- 政策/行业 RSS 监控自动入库
- **微信文档自动入库**（用户微信发送文件 → Markdown → AI 增强 → 入库到 01-WeiXin/）

## 工具脚本

### 健康巡检

```bash
uv run --with pyyaml python3 /opt/data/lint_vault.py
```

检查维度：
- **断链**：`[[wikilink]]` 指向不存在的页面（🔴 高优先级）
- **Frontmatter 缺失**：无 YAML frontmatter（🔴 高优先级）
- **孤立页面**：零入链的笔记（🟡 中）
- **标签/摘要覆盖**：是否达标（10 标签 + 5 条摘要）

Vault 路径：`/opt/data/Obsidian Vault/Obsidian Vault/`

### 断链修复

```bash
uv run --with pyyaml python3 /opt/data/fix_links.py
```

原理：建立 title→slug 映射表，将 frontmatter `related` 字段的 `[[标题]]` 替换为正确的 `[[slug]]`。

**断链根因**：`note_enhance.py` 生成 related 时用的是笔记标题（如 `[[什么是算力银行？]]`），但实际文件名是 slug（`算力银行-算力超市-Token工厂.md`）。Obsidian 按文件名匹配 wikilink，导致不匹配。

**修复率**：实测 511→21（96%），剩余 21 处指向真正不存在的笔记（需手动处理）。

### RSS 政策监控

```bash
uv run --with feedparser --with requests python3 /opt/data/rss_monitor.py
```

当前可用源（中国政府网站大多无 RSS）：
- 新华网-时政：`http://www.xinhuanet.com/politics/news_politics.xml`
- InfoQ-中文：`https://www.infoq.cn/feed`

流程：RSS 抓取 → 全文爬取 → Markdown 保存 → `note_enhance.py` 增强

### 微信文档实时入库

见 `references/weixin-ingest-pipeline.md` 获取完整实作细节。

## Cron 作业配置

当前知识库共有 **2 个入库管道 + 1 个巡检**：

| job_id | 任务 | 来源目录 | 目标目录 | 频率 | 模式 |
|--------|------|----------|----------|------|------|
| c3e92b82c93a | 文档自动入库 | `WebChat BackUp/文档/` | `concepts/` | 每天 9:00 | **Agent** |
| 5652f5032fe5 | 思源笔记同步入库 | NAS `INBOX_FILES/` | `00-INBOX/` | 每天 17:00 | **Agent** |
| f1e56e8511d3 | 知识库巡检 | — | — | 每月 1 号 9:00 | no_agent |

> 注：微信文档管道（01-WeiXin/）无定时任务，收到文件后实时处理。

### 模式选择：no_agent vs Agent

| 维度 | no_agent | Agent |
|------|----------|-------|
| Token 消耗 | 0 | 少量（deepseek-chat ≈ ¥0.0005/次） |
| 超时限制 | **120s 硬限制**（调度器固定，不可配置） | 无（Agent 用 terminal 工具跑脚本，脚本内部 timeout 生效） |
| 适合 | 脚本 ≤ 120s 能完成，无需 LLM | 脚本可能 > 120s（OCR 大 PDF、批量转换），或需 LLM 汇总结果 |
| 脚本位置 | 必须放 `$HERMES_HOME/scripts/`（真实文件，不能用符号链接） | 不限制，prompt 里写全路径 |

**关键坑**：no_agent 的 120s 超时是调度器硬限制。脚本再快的任务也可能因为一次慢文件（83 页扫描件 OCR）被打爆。如果任务稳定超时，果断切 Agent 模式。

### Agent 模式 cron 的写法

```yaml
# 不设 script，用 prompt 说明要做什么
cronjob:
  schedule: "0 9 * * *"
  prompt: "运行 cd /opt/data && python3 ingest_docs.py，循环执行直到无新文档，无论是否有新文档都用中文输出简短执行报告"
  # 注意：no_agent 必须是 false（默认）
```

### 微信文档实时入库

**原理**：用户在微信端向 Hermes 发送文件附件 → Hermes gateway 自动下载并缓存到 `cache/documents/`（文件名格式 `doc_{uuid12}_{原文件名}.ext`） → **我在对话中实时运行** `weixin_ingest.py` → 转换 Markdown → note_enhance 增强 → 入库到 `01-WeiXin/` → **缓存文件保留不删除**（防止入库失败需要重试，且 Hermes gateway 自带24小时清理机制）。

**脚本**：`/opt/data/scripts/weixin_ingest.py`

**关键逻辑**：
- 使用独立的 hash 日志 `$VAULT/.ingested_weixin` 去重（与 concepts/ 的 `.ingested` 隔离）
- 处理完成后**保留缓存文件不删除**（用户明确要求）
- 调用 `note_enhance.py` 时**传绝对路径**（note_enhance 已支持，见下面说明）
- 支持格式：docx, pdf, pptx, xls/xlsx, txt, md（同 concepts/ 管道）
- 每次最多处理 `MAX_PER_RUN = 20` 个文件

**微信文件缓存路径**：`$HERMES_HOME/cache/documents/`（本环境为 `/opt/data/cache/documents/`）

**与 concepts/ 管道的区别**：

| 维度 | concepts 管道 | 01-WeiXin 管道 |
|------|-------------|---------------|
| 来源 | `WebChat BackUp/文档/`（微信自动备份目录） | `cache/documents/`（实时聊天附件缓存） |
| 处理方式 | 保留原始文件（备份目录不动） | **保留缓存文件不删除** |
| 去重日志 | `.ingested` | `.ingested_weixin` |
| 触发方式 | 定时 9:00 cron | **实时**（我收到文件当场处理） |

Agent 模式会消耗少量 token 来驱动 terminal 调用，但脚本内部自己控制 timeout，300s/400s 的 subprocess timeout 不会被截断。

### 批次限制模式

`ingest_docs.py` 每次最多处理 20 个文件（`MAX_PER_RUN = 20`），避免单个执行被慢文件（OCR、加密 PDF）拖垮超时。剩余文件由后续执行逐步消化。

实现方式：
```python
MAX_PER_RUN = 20
unprocessed = [f for f in docs if not is_already_processed(str(f))]
for f in unprocessed[:MAX_PER_RUN]:
    ...
```

## 常见陷阱

- **巡检脚本显示断链数字偏高**：lint_vault.py 在用 `yaml.safe_load` 解析 related 字段时，字符串表示的 `[[slug]]` 会被多套一层引号显示为 `[['slug']]`。实际文件中的 wikilink 格式正确，是显示问题。
- **修复脚本修改大量文件**：`fix_links.py` 会重写所有含 related 字段的笔记。跑之前确保没有未提交的修改。
- **政府网站无标准 RSS**：国家数据局、民政部、发改委等官网均无 RSS 输出。新华网是目前唯一可靠的政策 RSS 源。如需覆盖特定部委，考虑网页爬取方案。
- **no_agent cron 脚本依赖**：Python 依赖（pyyaml、feedparser 等）未全局安装时，用 shell 包装脚本通过 `uv run --with <pkg>` 解决。脚本放 `/opt/data/scripts/`，**必须是真实文件**不能用符号链接（调度器会解析到外部路径并拦截）。
- **OCR 超大 PDF 跳过策略**：`MAX_OCR_PAGES` 已从 30 改为 99999（取消页数限制）。但 >80 页的扫描件 PDF（如培训照片、案例集 >300 页，200 页蓝皮书）会在 400s subprocess timeout 内未完成全部 OCR。这些文件**直接跳过**（hash 写入 `.ingested`），不做截断入库。手动手动处理方案：单独跑 `python3 pdf_ocr.py <path>` 并加更长 timeout，或分段 OCR。
- **symlink 陷阱**：`ln -sf` 创建的链接在 cron 沙箱中会被解析到真实路径，若超出 `/opt/data/scripts/` 范围则被拦截。用 `cp` 复制真实文件。
- **WeChat 限流误报**：`last_status: "error"` 可能只是微信发送被 iLink rate limited，脚本本身成功执行了。看 `agent.log` 中 `Job 'X': delivered to weixin` 确认脚本跑完；看 `errors.log` 中 `iLink sendmessage rate limited` 确认是发送层的问题。不要因为 status=error 就重跑脚本。
- **Agent 模式 cron 的 SILENT 陷阱**：不要在 cron prompt 里写类似"无新文档时输出 `[SILENT]` 以静默"的规则。即使无新内容，用户也需要知道任务正常执行了（执行时间、状态、无新文档确认）。否则用户会以为任务没跑。正确做法：**无论是否有新内容，都输出简短的中文执行报告**（包含执行时间、新入库数量、总数、状态）。
- **加密 PDF 拖垮批处理**：pymupdf 的 `len(doc)` 对加密 PDF 返回正确页数，但 `doc[i]` 抛 `ValueError("document closed or encrypted")`。单文件崩溃会导致整个 cron 超时。OCR 脚本（`pdf_ocr.py`）必须用 try/except 逐页防御。
- **微信文档缓存可能为空**：如果用户从未通过微信发送过文件附件，`cache/documents/` 目录存在但为空。脚本正常退出返回 `📭 缓存目录无文档文件`。这不是错误。
- **note_enhance.py 的 VAULT 硬编码**：`note_enhance.py` 的 `VAULT` 变量固定为 `concepts/` 目录。当微信入库脚本需要增强 `01-WeiXin/` 中的笔记时，必须传**绝对路径**给 note_enhance。note_enhance 的 main() 已支持绝对路径参数（`if p.is_absolute(): files.append(p)`）。调用示例如下而非使用 cwd：
  ```python
  subprocess.run(['python3', '/opt/data/note_enhance.py', absolute_path], timeout=300)
  ```
