---
name: document-to-knowledge-note
description: Convert office documents (DOCX/PDF/PPTX/XLS) into structured Markdown knowledge notes for Obsidian vault.
version: 1.0.0
---

# Document → Knowledge Note

将办公文档（Word/PDF/PPT/Excel）提取并转化为结构化 Markdown 知识笔记，存入 Obsidian 知识库。

## 自动化流水线（已就绪）

本 skill 已有三条完整的自动化流水线：

### 管道①：WebChat 文档入库（定时 9:00）
```bash
python3 /opt/data/ingest_docs.py
```
- 扫描 `/opt/data/WebChat BackUp/文档/` 及其子目录
- 入库到 `concepts/`
- 每天 9:00 自动（cron `c3e92b82c93a`）

### 管道②：思源笔记同步（定时 17:00）
```bash
python3 /opt/data/siyuan_sync.py
```
- 从 NAS `/opt/data/INBOX_FILES/workspace/data/` 提取 `.sy` 文件
- 自动转写 `NodeAudio` 语音节点（SenseVoiceSmall API）
- 入库到 `00-INBOX/`
- 每天 17:00 自动（cron `5652f5032fe5`）

### 管道③：微信实时文档入库（即时触发）
```bash
python3 /opt/data/scripts/weixin_ingest.py
```
- 用户通过微信发送的文档文件，Hermes 自动缓存到 `/opt/data/cache/documents/`
- **手动触发**（无定时任务）：我收到文件后立即处理
- 入库到 `01-WeiXin/`
- 处理完后**保留缓存文件**（以便失败重试，不清除）
- 独立去重记录：`.ingested_weixin`（与 `.ingested` 分开）

详见 `references/weixin-ingest-pipeline.md`。

### 统一增强流程
三条管道入库后都会调用 `note_enhance.py`：
1. **递归扫描** `/opt/data/WebChat BackUp/文档/` 及其所有子目录中的文档（`glob('**/*')`）
2. 按格式调用对应转换库（docx→python-docx, pdf→pymupdf, pptx→python-pptx, xls→xlrd+openpyxl）
3. 写入 `/opt/data/Obsidian Vault/Obsidian Vault/concepts/`
4. 调用 `note_enhance.py` 生成规范化 YAML frontmatter（摘要5条×、标签10个、关联[[wikilink]]）
5. MD5 去重，已处理文档自动跳过
6. 每次增强超时 **300s**（deepseek-chat 3次调用约需 5-15s，偶发慢需更长）
- **OCR 页数限制（已解除）**：`pdf_ocr.py` 原设 `MAX_OCR_PAGES=30`（2026-06-21 **已改为 `MAX_OCR_PAGES=99999`**，不再截断 PDF）。OCR subprocess 超时 400s。**超大扫描件**（>80页如培训照片、456页案例集）因逐页 API 调用会持续超时，超额页面跳过策略见下方注意事项

**Cron 自动运行**：每日 9:00（job `c3e92b82c93a`）

详见 `note-enhance` skill 的 `references/ingest-pipeline.md`。

**模型选择**：增强调用 `note_enhance.py`，当前使用 DeepSeek 官方 `deepseek-chat`（0.43s/篇，¥0.005/篇）。详见 `note-enhance` skill。

## 工作流

### Step 1: 确定 Vault 路径

```bash
echo "${OBSIDIAN_VAULT_PATH:-unset}"
grep -i obsidian ~/.hermes/.env 2>/dev/null
ls -d /opt/data/Obsidian* 2>/dev/null
```

若 vault 路径无写权限，回退到 `/opt/data/知识笔记/`。

### Step 2: 提取各类型文档

| 文件类型 | 工具 | 命令模板 |
|---------|------|---------|
| `.docx` | `python-docx` | `uv run --with python-docx python3 -c "..."` |
| `.pdf` | `pymupdf` | `uv run --with pymupdf python3 -c "..."` |
| `.pptx` | `python-pptx` | `uv run --with python-pptx python3 -c "..."` |
| `.xlsx` | `openpyxl` | `uv run --with openpyxl python3 -c "..."` |
| `.xls` | `xlrd` (fallback) | 旧格式，先试 openpyxl，失败再用 xlrd |

**回退模式**：若 `terminal()` 带 `-c` 被阻塞，将脚本写入 `/tmp/extract_<type>.py`，然后 `uv run --with <pkg> python3 /tmp/script.py`。

### Step 3: 提炼为结构化 Markdown

输出格式规范：
- **YAML frontmatter 风格头部**：`>` 引用块标注来源、日期、原始文件名
- **关联链接**：使用 `[[WikiLink]]` 链接相关知识笔记
- **表格优先**：进度、清单、对比数据用表格呈现
- **摘要式结构**：政府汇报类文档提取关键结论和风险，不逐字搬运
- **关键要点速查**：文末附 Key Takeaways 或速查表

### Step 4: 写入 Obsidian Vault

```bash
write_file path="/opt/data/Obsidian Vault/Obsidian Vault/<笔记名>.md"
```

若 vault 权限不足（root 属主），回退到 `/opt/data/知识笔记/`。

## 用户工作规范（必遵守）

这些规则适用于本技能覆盖的所有自动化任务（文档入库、OCR 分批处理、cron 运维等）：

1. **出错立即汇报**：遇到错误（超时、路径问题、API 失败等），立即向用户报告错误详情和原因，等待用户指示是否调整方案。不默默跳过、不自行替换方案。
2. **任务结束出总结报告**：所有自动化任务执行完毕后出具完整总结报告，包含：
   - 成功/失败数量及具体文件名
   - 耗时和批次信息
   - 关键配置变更
   - 剩余待办事项（如有）
   - 报告要自包含，让用户一眼看清结果

## 注意事项

- 中文文件名需在脚本内用 glob 定位，避免 shell 引号问题
- `markitdown` 对 PPTX 首次运行会下载依赖（numpy/onnxruntime/magika），预留 60s 超时
- `pymupdf` 约 25MB，首次 `uv run --with` 会安装
- PDF 超时（如300s）时，检查是否是首次下载依赖，重试一次即可
- **LibreOffice 免安装部署**：用于 PPTX/PDF 高级转换。从 USTC 镜像下载 deb.tar.gz → dpkg-deb 提取 → 通过 `soffice.bin` + `SAL_USE_VCLPLUGIN=svp` 在 headless 模式运行。详见 `references/libreoffice-portable.md`
- **DOCX 生成编码陷阱**：`write_file` 工具会转义中文弯引号「""」，导致 Python 语法错误。改用 JSON 数据文件 + terminal heredoc 方式生成 DOCX
- **python-docx 位置**：安装在 `/opt/hermes/.venv/bin/python3`，非系统 python3
- **大扫描件 OCR 超时** ⚠️：培训照片类 PDF 可达 80+ 页、每页 ~4MB 图片，逐页 OCR 需 >600s。策略变更记录：
  - 2026-06-20 之前：`MAX_OCR_PAGES=30` 限制页数，截断内容
  - 2026-06-21：用户要求**取消上限重新完整 OCR**，改为 `MAX_OCR_PAGES=99999`
  - **取消上限后**：超大扫描件在 400s subprocess timeout 内无法完成全量 OCR
  - **当前策略**：不再跳过超大PDF！用 `batch_ocr_remaining.py` 自动分批 OCR（30页/批，断点续传），逐步跑完。进度保存在 `.ocr_progress.json`，中断可续跑
  - 2026-06-21 实测：5个PDF共975页，30批全部跑完，累计约2小时
- **PaddleOCR 对培训照片可能输出乱码（韩文等）**，需人工检查 OCR 质量
- **WeChat 实时管道缓存保留**：`weixin_ingest.py` 处理完缓存文件后**不删除**，保留在 `/opt/data/cache/documents/` 供重试和留底
  - **取消上限后**：超大扫描件（83~456页）在 400s subprocess timeout 内无法完成全量 OCR
  - **当前策略**：不再跳过超大PDF！用 `batch_ocr_remaining.py` 自动分批 OCR（30页/批，断点续传），逐步跑完。进度保存在 `.ocr_progress.json`，中断可续跑
  - 2026-06-21 实测：5个PDF共975页，30批全部跑完，累计约2小时
- **PaddleOCR 对培训照片可能输出乱码（韩文等）**，需人工检查 OCR 质量
- **子目录文件 MD5 去重** ✅：`ingest_docs.py` 用 `glob('**/*')` 递归扫描所有子目录，MD5 hash 去重运行正常。截至 2026-06-21，707 个文档中仅剩 0 个待处理。空内容文件（docx/xlsx/pptx 占位模板无正文）会被正确跳过（hash 已写入 `.ingested`）
